import { create } from 'zustand';
import { initialLeadData } from '@/components/resumo-base/resumoBaseUtils';
import { toast } from '@/components/ui/use-toast';
import { uploadLeadsToSupabase, getLeadsFromSupabase, logActivity, clearAllSupabaseLeads } from '@/services/supabaseService';
import { fetchSheetData } from '@/services/googleApiService';
import Papa from 'papaparse';

const normalizeHeader = (header) => {
  return String(header || '')
    .trim()
    .toUpperCase()
    .replace(/\s+/g, '_')
    .replace(/"/g, '')
    .replace(/ID_CREDCESTA/g, 'ID_CREDCESTA')
    .replace(/SAQUE_CREDCESTA/g, 'SAQUE_CREDCESTA')
    .replace(/NÃO_PERTUBE/g, 'NAO_PERTURBE')
    .replace(/MENSAGEM_ERRO/g, 'MENSAGEM_ERRO');
};

const processRawDataToLeads = (rawData) => {
  if (!rawData || rawData.length < 2) {
    const errorMsg = "Os dados da fonte devem conter cabeçalho e pelo menos uma linha de dados.";
    toast({ title: "Dados Inválidos", description: errorMsg, variant: "destructive" });
    logActivity({ action_type: 'PROCESS_DATA', status: 'FAILURE', details: { error: errorMsg } });
    return null;
  }

  const headerFromFile = rawData[0].map(h => normalizeHeader(h));
  const requiredHeaders = ['CPF', 'NOME', 'TELEFONE'];
  const missingRequired = requiredHeaders.filter(h => !headerFromFile.includes(h));

  if (missingRequired.length > 0) {
    const errorMsg = `Os seguintes cabeçalhos são obrigatórios na sua planilha/CSV: ${missingRequired.join(', ')}`;
    toast({ title: "Cabeçalhos Obrigatórios Ausentes", description: errorMsg, variant: "destructive", duration: 8000 });
    logActivity({ action_type: 'PROCESS_DATA', status: 'FAILURE', details: { error: errorMsg, missing: missingRequired } });
    return null;
  }

  const data = rawData.slice(1).map((row, index) => {
    let obj = {};
    headerFromFile.forEach((header, colIndex) => {
      let value = row[colIndex] !== undefined ? String(row[colIndex]).trim().replace(/"/g, '') : '';
      const keyToStore = header.toLowerCase().replace(/ /g, '_');
      
      if (['limite_disponivel', 'saque_credcesta', 'saque_cred_cesta', 'idade', 'renda', 'id_credcesta', 'limite_utilizado', 'limite_total', 'valor_limite_parcela', 'limite_parcela_utilizado'].includes(keyToStore)) {
        value = parseFloat(String(value).replace(',', '.')) || 0;
      } else if (keyToStore === 'nao_perturbe' || keyToStore === 'não_perturbe') {
        value = ['true', '1', 'sim'].includes(String(value).toLowerCase());
      }
      obj[keyToStore] = value;
    });

    obj.banco = obj.banco || 'Não Informado';
    obj.convenio = obj.convenio || 'Não Informado';
    obj.produto = obj.produto || 'Não Informado';
    obj.perfil = obj.perfil || 'Não Informado';
    obj.estado = obj.estado || 'Não Informado';
    obj.origem_planilha = `Linha ${index + 2}`;
    
    return obj;
  });

  return data;
};

export const useLeadStore = create((set, get) => ({
  leads: initialLeadData,
  isLoading: false,

  setLeads: (leads) => set({ leads }),

  loadLeadsFromSupabase: async () => {
    set({ isLoading: true });
    const { data, error } = await getLeadsFromSupabase();
    if (error) {
      logActivity({ action_type: 'LOAD_LEADS_SUPABASE', status: 'FAILURE', details: { error: error.message } });
    } else {
      logActivity({ action_type: 'LOAD_LEADS_SUPABASE', status: 'SUCCESS', details: { count: data?.length || 0 } });
    }
    set({ leads: data || [], isLoading: false });
  },
  
  saveLeadsToSupabase: async (leadsToSave) => {
    if (!leadsToSave || leadsToSave.length === 0) return;
    set({ isLoading: true });
    const { data, error } = await uploadLeadsToSupabase(leadsToSave);
    if (error) {
      logActivity({ action_type: 'SAVE_LEADS_SUPABASE', status: 'FAILURE', details: { error: error.message, count: leadsToSave.length } });
    } else {
      logActivity({ action_type: 'SAVE_LEADS_SUPABASE', status: 'SUCCESS', details: { count: leadsToSave.length } });
      set({ leads: leadsToSave });
    }
    set({ isLoading: false });
  },

  handleLeadUploadFromFile: async (file) => {
    if (!file) return;
    set({ isLoading: true });
    logActivity({ action_type: 'UPLOAD_LEADS_CSV', status: 'STARTED', details: { fileName: file.name, size: file.size } });
    Papa.parse(file, {
      complete: async (result) => {
        const processedData = processRawDataToLeads(result.data);
        if (processedData) {
          await get().saveLeadsToSupabase(processedData);
        }
        set({ isLoading: false });
      },
      error: (error) => {
        toast({ title: "Erro no Parsing do CSV", description: error.message, variant: "destructive" });
        logActivity({ action_type: 'UPLOAD_LEADS_CSV', status: 'FAILURE', details: { error: error.message, fileName: file.name } });
        set({ isLoading: false });
      }
    });
  },

  syncLeadsFromGoogleSheet: async (sheetId, range) => {
    if (!sheetId) {
      toast({ title: "ID Obrigatório", description: "Por favor, forneça o ID da planilha.", variant: "destructive" });
      return;
    }
    
    set({ isLoading: true });
    const effectiveRange = range && range.trim() !== '' ? range.trim() : 'Página1!A1:Z1000';
    logActivity({ action_type: 'SYNC_GOOGLE_SHEETS', status: 'STARTED', details: { sheetId, range: effectiveRange } });

    try {
      toast({ title: "Sincronizando...", description: `Buscando dados da planilha: ${sheetId}` });
      const rawData = await fetchSheetData(sheetId, effectiveRange);
      if (rawData) {
        const processedData = processRawDataToLeads(rawData);
        if (processedData) {
          await get().saveLeadsToSupabase(processedData);
        }
      }
    } catch (error) {
      toast({ title: "Erro na Sincronização", description: `Falha ao sincronizar com Google Sheets. ${error.message}`, variant: "destructive" });
      logActivity({ action_type: 'SYNC_GOOGLE_SHEETS', status: 'FAILURE', details: { error: error.message, sheetId } });
    } finally {
      set({ isLoading: false });
    }
  },

  clearAllLeads: async () => {
    set({ isLoading: true });
    const { error } = await clearAllSupabaseLeads();
    if (!error) {
      set({ leads: [] });
    }
    set({ isLoading: false });
  },
}));