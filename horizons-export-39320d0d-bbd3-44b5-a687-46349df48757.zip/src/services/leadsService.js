import { uploadLeadsToSupabase, getLeadsFromSupabase, clearAllSupabaseLeads } from '@/services/supabaseService';
import { toast } from '@/components/ui/use-toast';

export async function salvarLeads(leadsArray) {
  if (!leadsArray || leadsArray.length === 0) {
    console.warn("salvarLeads: Tentativa de salvar um array vazio.");
    return;
  }
  toast({ title: "Redirecionando para Supabase...", description: `Salvando ${leadsArray.length} leads.` });
  await uploadLeadsToSupabase(leadsArray);
}

export async function listarLeads() {
  toast({ title: "Buscando dados...", description: "Carregando leads do Supabase." });
  const { data, error } = await getLeadsFromSupabase();
  if (error) {
    return [];
  }
  return data || [];
}

export async function limparLeads() {
  toast({ title: "Limpando base de dados...", description: "Removendo todos os leads do Supabase." });
  await clearAllSupabaseLeads();
}