import Papa from 'papaparse';
import { salvarLeads, listarLeads } from '@/services/leadsService';
import { toast } from '@/components/ui/use-toast';

const GOOGLE_SHEET_URLS = [
  'https://docs.google.com/spreadsheets/d/1Zc-cBWljjVfzJOiqqC7F2REXLaTaOM_NXDwzkEX-7jo/export?format=csv&gid=1270535095',
  
  
];

const normalizeHeader = (header) => {
  if (!header) return '';
  return header.trim().toUpperCase().replace(/\s+/g, '_').replace(/"/g, '');
};

function processarRow(row, sheetUrl) {
  const normalizedRow = {};
  for (const key in row) {
    normalizedRow[normalizeHeader(key)] = row[key];
  }

  return {
    cpf: String(normalizedRow.CPF || '').replace(/\D/g, '').padStart(11, '0'),
    nome: normalizedRow.NOME || '',
    telefone: normalizedRow.TELEFONE || '',
    nascimento: normalizedRow.NASCIMENTO || '',
    convenio: normalizedRow.CONVENIO || '',
    margem: normalizedRow['MARGEM_DISPONÍVEL'] || normalizedRow.MARGEM || '', 
    produto: normalizedRow.PRODUTO || '',
    id_credcesta: normalizedRow.ID_CREBCESTA || normalizedRow.ID_CREDCESTA || '',
    matricula: normalizedRow.MATRICULA || '',
    mensagem_erro: normalizedRow.MENSAGEM_ERRO || '',
    saque_credcesta: normalizedRow.SAQUE_CREBCESTA || normalizedRow.SAQUE_CREDCESTA || '',
    tipo_de_saque: normalizedRow.TIPO_DE_SAQUE || '',
    nao_perturbe: String(normalizedRow.NÃO_PERTUBE || normalizedRow.NAO_PERTURBE || 'false').toLowerCase() === 'true',
    saque_complementar: normalizedRow.SAQUE_COMPLEMENTAR || '',
    data_consulta: normalizedRow.DATA_CONSULTA || '',
    limite_utilizado: normalizedRow.LIMITE_UTILIZADO || '',
    limite_total: normalizedRow.LIMITE_TOTAL || '',
    limite_disponivel: normalizedRow.LIMITE_DISPONIVEL || '',
    valor_limite_parcela: normalizedRow.VALOR_LIMITE_PARCELA || '',
    limite_parcela_utilizado: normalizedRow.LIMITE_PARCELA_UTILIZADO || '',
    banco: normalizedRow.BANCO || 'Origem Google Sheets',
    perfil: normalizedRow.PERFIL || 'Não Informado',
    estado: normalizedRow.ESTADO || 'Não Informado',
    origem_planilha: sheetUrl 
  };
}

function importarDeUmaUrl(url) {
  return new Promise((resolve, reject) => {
    Papa.parse(url, {
      download: true,
      header: true,
      skipEmptyLines: true,
      complete: (resultado) => {
        if (resultado.errors && resultado.errors.length > 0) {
          console.error(`Erros ao processar a URL ${url}:`, resultado.errors);
          toast({
            title: `Erro ao processar planilha`,
            description: `Houve erros ao ler dados da URL: ${url.substring(0, 50)}...`,
            variant: "destructive"
          });
          reject(new Error(`Erros ao processar a URL ${url}: ${JSON.stringify(resultado.errors)}`));
          return;
        }
        const dados = resultado.data.map(row => processarRow(row, url));
        resolve(dados);
      },
      error: (error) => {
        console.error(`Erro no Papa.parse para URL ${url}:`, error);
        toast({
          title: `Falha ao buscar planilha`,
          description: `Não foi possível buscar ou processar a URL: ${url.substring(0,50)}...`,
          variant: "destructive"
        });
        reject(error);
      }
    });
  });
}

export async function importarLeadsDeTodasAsPlanilhas() {
  if (GOOGLE_SHEET_URLS.length === 0) {
    console.log("Nenhuma URL de planilha configurada para importação.");
    return [];
  }
  
  toast({
    title: "Iniciando Importação de Planilhas",
    description: `Carregando dados de ${GOOGLE_SHEET_URLS.length} planilha(s)... Isso pode levar alguns instantes.`,
  });

  try {
    const promessas = GOOGLE_SHEET_URLS.map(url => importarDeUmaUrl(url).catch(e => {
      console.error(`Falha ao importar da URL ${url}: `, e.message);
      return []; 
    }));
    
    const todasBases = await Promise.all(promessas);
    const leadsUnificados = todasBases.flat().filter(lead => lead && lead.cpf && lead.cpf !== '00000000000');

    if (leadsUnificados.length > 0) {
      await salvarLeads(leadsUnificados);
      toast({
        title: "Importação de Planilhas Concluída!",
        description: `${leadsUnificados.length} leads foram processados e salvos no banco de dados local.`,
        variant: "success"
      });
    } else if (GOOGLE_SHEET_URLS.length > 0) {
        toast({
            title: "Nenhum Lead Válido Importado",
            description: "As planilhas foram processadas, mas nenhum lead válido (com CPF) foi encontrado.",
            variant: "warning"
        });
    }
    return leadsUnificados;
  } catch (error) {
    console.error("Erro geral ao importar leads de todas as planilhas:", error);
    toast({
      title: "Erro Crítico na Importação",
      description: "Ocorreu um erro inesperado ao tentar importar as planilhas. Verifique o console.",
      variant: "destructive"
    });
    return []; 
  }
}