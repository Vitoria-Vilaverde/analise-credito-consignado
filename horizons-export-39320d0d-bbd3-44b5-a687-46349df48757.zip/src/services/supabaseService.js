import { createClient } from '@supabase/supabase-js';
import { toast } from '@/components/ui/use-toast';

let supabaseInstance = null;
let supabaseInitialized = false;

const TARGET_TABLE_NAME = 'Base de Leads';

export const initializeSupabaseClient = () => {
  if (supabaseInstance) {
    return { success: true, supabase: supabaseInstance };
  }

  const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
  const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
    console.error("Supabase URL ou Anon Key não definidos.");
    return { success: false, supabase: null };
  }

  try {
    supabaseInstance = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    if (supabaseInstance && !supabaseInitialized) {
      supabaseInitialized = true;
      toast({
        title: "Supabase Conectado!",
        description: "Cliente Supabase inicializado com sucesso.",
      });
    }
    return { success: true, supabase: supabaseInstance };
  } catch (error) {
    console.error("Erro ao inicializar cliente Supabase:", error);
    return { success: false, supabase: null };
  }
};

export async function signOutUser() {
  if (!supabaseInstance) return;
  const { error } = await supabaseInstance.auth.signOut();
  if (error) {
    toast({ title: "Erro no Logout", description: error.message, variant: "destructive" });
    console.error('Error signing out:', error);
  }
}

const mapLeadToSupabaseSchema = (lead) => ({
  "CPF": lead.cpf ? String(lead.cpf).replace(/\D/g, '') : null,
  "MATRICULA": lead.matricula,
  "NOME": lead.nome,
  "NASCIMENTO": lead.nascimento,
  "TELEFONE": lead.telefone,
  "MENSAGEM ERRO": lead.mensagem_erro,
  "ID CREDCESTA": lead.id_credcesta,
  "CONVENIO": lead.convenio,
  "SAQUE CREDCESTA": lead.saque_credcesta,
  "TIPO DE SAQUE": lead.tipo_de_saque,
  "NÃO PERTUBE": String(lead.nao_perturbe),
  "SAQUE COMPLEMENTAR": lead.saque_complementar,
  "DATA CONSULTA": lead.data_consulta,
  "LIMITE UTILIZADO": lead.limite_utilizado,
  "LIMITE TOTAL": lead.limite_total,
  "LIMITE DISPONIVEL": lead.limite_disponivel,
  "VALOR LIMITE PARCELA": lead.valor_limite_parcela,
  "LIMITE PARCELA UTILIZADO": lead.limite_parcela_utilizado,
});

const robustParseFloat = (value) => {
  if (value === null || value === undefined || value === '') return 0;
  if (typeof value === 'number') return value;

  let strValue = String(value).trim();
  
  strValue = strValue
    .replace(/R\$\s*/g, '')
    .replace(/\./g, (match, offset, original) => {
      return offset < original.lastIndexOf(',') ? '' : '.';
    })
    .replace(',', '.');

  const number = parseFloat(strValue);
  return isNaN(number) ? 0 : number;
};


const mapSupabaseToLeadSchema = (dbLead) => {
    const limiteDisponivel = robustParseFloat(dbLead["LIMITE DISPONIVEL"]);
    const saqueCredcesta = robustParseFloat(dbLead["SAQUE CREDCESTA"]);

    let idade = null;
    if (dbLead["NASCIMENTO"]) {
        let birthDate;
        const nascimentoStr = String(dbLead["NASCIMENTO"]);
        if (nascimentoStr.includes('/')) {
            const parts = nascimentoStr.split('/');
            if (parts.length === 3) {
                birthDate = new Date(`${parts[2]}-${parts[1]}-${parts[0]}`);
            }
        } else if (nascimentoStr.includes('-')) {
            birthDate = new Date(nascimentoStr);
        }
        
        if (birthDate && !isNaN(birthDate.getTime())) {
            const ageDifMs = Date.now() - birthDate.getTime();
            const ageDate = new Date(ageDifMs);
            idade = Math.abs(ageDate.getUTCFullYear() - 1970);
        }
    }

    let perfil = 'Não Tomador';
    if (limiteDisponivel > 0 || saqueCredcesta > 0) {
        perfil = 'Tomador';
    }

    let estado = 'Não Informado';
    const telefone = String(dbLead["TELEFONE"] || '').replace(/\D/g, '');
    if (telefone.length >= 10) {
        const ddd = telefone.substring(0, 2);
        const dddMap = {
            '68': 'AC', '82': 'AL', '96': 'AP', '92': 'AM', '97': 'AM', '71': 'BA', '73': 'BA', '74': 'BA', '75': 'BA', '77': 'BA',
            '85': 'CE', '88': 'CE', '61': 'DF', '27': 'ES', '28': 'ES', '62': 'GO', '64': 'GO', '98': 'MA', '99': 'MA',
            '65': 'MT', '66': 'MT', '67': 'MS', '31': 'MG', '32': 'MG', '33': 'MG', '34': 'MG', '35': 'MG', '37': 'MG', '38': 'MG',
            '91': 'PA', '93': 'PA', '94': 'PA', '83': 'PB', '81': 'PE', '87': 'PE', '41': 'PR', '42': 'PR', '43': 'PR', '44': 'PR', '45': 'PR', '46': 'PR',
            '86': 'PI', '89': 'PI', '21': 'RJ', '22': 'RJ', '24': 'RJ', '84': 'RN', '51': 'RS', '53': 'RS', '54': 'RS', '55': 'RS',
            '69': 'RO', '95': 'RR', '47': 'SC', '48': 'SC', '49': 'SC', '11': 'SP', '12': 'SP', '13': 'SP', '14': 'SP', '15': 'SP', '16': 'SP', '17': 'SP', '18': 'SP', '19': 'SP',
            '79': 'SE', '63': 'TO'
        };
        if (dddMap[ddd]) {
            estado = dddMap[ddd];
        }
    }

    return {
        cpf: dbLead["CPF"] ? String(dbLead["CPF"]) : '',
        matricula: dbLead["MATRICULA"] || '',
        nome: dbLead["NOME"] || '',
        nascimento: dbLead["NASCIMENTO"] || '',
        telefone: dbLead["TELEFONE"] || '',
        mensagem_erro: dbLead["MENSAGEM ERRO"] || '',
        id_credcesta: dbLead["ID CREDCESTA"] || '',
        convenio: dbLead["CONVENIO"] || 'Não Informado',
        saque_credcesta: saqueCredcesta,
        tipo_de_saque: dbLead["TIPO DE SAQUE"] || '',
        nao_perturbe: ['true', '1', 'sim'].includes(String(dbLead["NÃO PERTUBE"]).toLowerCase()),
        saque_complementar: dbLead["SAQUE COMPLEMENTAR"] || '',
        data_consulta: dbLead["DATA CONSULTA"] || '',
        limite_utilizado: robustParseFloat(dbLead["LIMITE UTILIZADO"]),
        limite_total: robustParseFloat(dbLead["LIMITE TOTAL"]),
        limite_disponivel: limiteDisponivel,
        valor_limite_parcela: robustParseFloat(dbLead["VALOR LIMITE PARCELA"]),
        limite_parcela_utilizado: robustParseFloat(dbLead["LIMITE PARCELA UTILIZADO"]),
        margem: limiteDisponivel,
        idade: idade,
        perfil: perfil,
        estado: estado,
        banco: 'Não Informado',
        produto: 'Não Informado',
        origem_planilha: 'Supabase',
    };
};

export async function uploadLeadsToSupabase(leads) {
  if (!supabaseInstance) return { data: null, error: { message: "Supabase not initialized." } };
  
  toast({ title: "Enviando para Supabase...", description: `Enviando ${leads.length} leads.`});
  
  const leadsToInsert = leads.map(mapLeadToSupabaseSchema);
  const { data, error } = await supabaseInstance.from(TARGET_TABLE_NAME).upsert(leadsToInsert, { onConflict: 'CPF' });

  if (error) {
    toast({ title: "Erro no Upload para Supabase", description: error.message, variant: "destructive" });
  } else {
    toast({ title: "Upload para Supabase Concluído!", description: `Leads processados com sucesso.` });
  }
  return { data, error };
}

export async function getLeadsFromSupabase() {
  if (!supabaseInstance) return { data: null, error: { message: "Supabase not initialized." } };
  
  toast({ title: "Buscando leads do Supabase..." });
  const { data, error } = await supabaseInstance.from(TARGET_TABLE_NAME).select('*');

  if (error) {
    toast({ title: "Erro ao Buscar Leads", description: error.message, variant: "destructive" });
    return { data: null, error };
  } else {
    const formattedData = data.map(mapSupabaseToLeadSchema);
    toast({ title: "Leads Carregados!", description: `${formattedData.length} leads recebidos do Supabase.` });
    return { data: formattedData, error: null };
  }
}

export async function clearAllSupabaseLeads() {
  if (!supabaseInstance) return { error: { message: "Supabase not initialized." } };
  
  toast({ title: "Limpando Tabela...", description: `Removendo todos os leads da tabela ${TARGET_TABLE_NAME}.` });

  const { error } = await supabaseInstance.from(TARGET_TABLE_NAME).delete().neq('CPF', '-1'); 

  if (error) {
    toast({ title: "Erro ao Limpar Tabela", description: error.message, variant: "destructive" });
    logActivity({ action_type: 'CLEAR_LEADS_SUPABASE', status: 'FAILURE', details: { error: error.message } });
  } else {
    toast({ title: "Sucesso!", description: "Todos os leads foram removidos da base no Supabase." });
    logActivity({ action_type: 'CLEAR_LEADS_SUPABASE', status: 'SUCCESS' });
  }
  return { error };
}

export async function logActivity(logData) {
  if (!supabaseInstance) return;

  const { data: { user } } = await supabaseInstance.auth.getUser();
  const logPayload = {
    user_email: user?.email,
    ...logData,
  };

  const { error } = await supabaseInstance.from('activity_logs').insert(logPayload);
  if (error) {
    console.error('Error logging activity:', error);
  }
}

export async function getActivityLogs() {
  if (!supabaseInstance) return { data: null, error: { message: "Supabase not initialized." } };
  
  const { data, error } = await supabaseInstance
    .from('activity_logs')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(100);

  return { data, error };
}