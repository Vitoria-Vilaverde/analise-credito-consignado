import { gapi } from 'gapi-script';
import { toast } from '@/components/ui/use-toast';

let googleAuthInstance = null;
let isInitialized = false;

export const initGoogleClient = (callback) => {
  if (isInitialized) {
    if (callback) callback(googleAuthInstance?.isSignedIn?.get() || false);
    return;
  }
  
  const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
  const API_KEY = import.meta.env.VITE_GOOGLE_API_KEY;

  if (!CLIENT_ID || !API_KEY) {
    toast({ title: "Erro de Configuração", description: "ClientID ou API Key do Google não encontrados.", variant: "destructive"});
    return;
  }

  const script = document.createElement('script');
  script.src = 'https://apis.google.com/js/api.js';
  document.body.appendChild(script);

  script.onload = () => {
    gapi.load('client:auth2', () => {
      gapi.client.init({
        apiKey: API_KEY,
        clientId: CLIENT_ID,
        discoveryDocs: ["https://sheets.googleapis.com/$discovery/rest?version=v4"],
        scope: "https://www.googleapis.com/auth/spreadsheets.readonly"
      }).then(() => {
        googleAuthInstance = gapi.auth2.getAuthInstance();
        isInitialized = true;
        googleAuthInstance.isSignedIn.listen(callback);
        callback(googleAuthInstance.isSignedIn.get());
      }).catch(error => {
        console.error("Erro ao inicializar Google Client:", error);
        toast({ title: "Erro na API Google", description: error.details || "Não foi possível carregar a API do Google.", variant: "destructive"});
      });
    });
  };
  script.onerror = () => {
    toast({ title: "Erro de Script", description: "Não foi possível carregar o script da API do Google.", variant: "destructive"});
  };
};

export const signInToGoogle = async () => {
  if (!googleAuthInstance) {
    toast({ title: "API não pronta", description: "Aguarde a inicialização da API do Google.", variant: "warning"});
    return;
  }
  try {
    await googleAuthInstance.signIn();
  } catch (error) {
    console.error('Google Sign-in failed:', error);
    toast({ title: "Erro no Login Google", description: error.details || "Ocorreu um problema durante o login.", variant: "destructive"});
  }
};

export const signOutFromGoogle = () => {
  if (googleAuthInstance) {
    googleAuthInstance.signOut();
  }
};

export const fetchSheetData = async (spreadsheetId, range) => {
  if (!googleAuthInstance || !googleAuthInstance.isSignedIn.get()) {
    toast({ title: "Não Autenticado", description: "Faça login com o Google para acessar planilhas privadas.", variant: "warning"});
    throw new Error('User not authenticated');
  }
  try {
    const response = await gapi.client.sheets.spreadsheets.values.get({
      spreadsheetId: spreadsheetId,
      range: range,
    });
    return response.result.values;
  } catch (err) {
    console.error("Google API error:", err);
    toast({ title: "Erro na API do Google", description: err.result?.error?.message || "Não foi possível buscar os dados da planilha.", variant: "destructive"});
    throw err;
  }
};

export const isGoogleAuthReady = () => {
  return isInitialized;
};

export const isGoogleSignedIn = () => {
  if (!googleAuthInstance) return false;
  return googleAuthInstance.isSignedIn.get();
};