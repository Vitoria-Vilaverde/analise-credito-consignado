import { useState, useEffect, useCallback } from 'react';
import { 
  initGoogleClient, 
  signInToGoogle, 
  signOutFromGoogle,
  isGoogleSignedIn,
  isGoogleAuthReady as checkGoogleAuthReady
} from '@/services/googleApiService';

export const useGoogleApi = (toast) => {
  const [isGoogleAuthReady, setIsGoogleAuthReady] = useState(false);
  const [isGoogleSignedIn, setIsGoogleSignedIn] = useState(false);

  const updateGoogleSignInStatus = useCallback((signedIn) => {
    console.log('Google Sign-in Status Update:', signedIn);
    setIsGoogleSignedIn(signedIn);
    setIsGoogleAuthReady(true);
    
    if (signedIn) {
      toast({ 
        title: "Google Conectado", 
        description: "Autenticação com Google realizada com sucesso!" 
      });
    }
  }, [toast]);

  useEffect(() => {
    const initializeGoogle = async () => {
      try {
        await initGoogleClient(updateGoogleSignInStatus);
        setIsGoogleAuthReady(checkGoogleAuthReady());
        setIsGoogleSignedIn(isGoogleSignedIn());
      } catch (error) {
        console.error('Failed to initialize Google API:', error);
        toast({ 
          title: "Erro na Inicialização", 
          description: "Falha ao inicializar a API do Google", 
          variant: "destructive" 
        });
      }
    };

    initializeGoogle();
  }, [updateGoogleSignInStatus, toast]);

  const handleGoogleSignIn = useCallback(async () => {
    if (!isGoogleAuthReady) {
      toast({ 
        title: "API não está pronta", 
        description: "Aguarde a inicialização da API do Google", 
        variant: "destructive" 
      });
      return;
    }

    try {
      await signInToGoogle();
    } catch (error) {
      console.error('Sign-in error:', error);
      toast({ 
        title: "Erro no Login", 
        description: "Falha ao fazer login com Google", 
        variant: "destructive" 
      });
    }
  }, [isGoogleAuthReady, toast]);

  const handleGoogleSignOut = useCallback(() => {
    try {
      signOutFromGoogle();
      setIsGoogleSignedIn(false);
      toast({ 
        title: "Google Desconectado", 
        description: "Você foi desconectado do Google" 
      });
    } catch (error) {
      console.error('Sign-out error:', error);
      toast({ 
        title: "Erro no Logout", 
        description: "Falha ao desconectar do Google", 
        variant: "destructive" 
      });
    }
  }, [toast]);

  return {
    isGoogleAuthReady,
    isGoogleSignedIn,
    handleGoogleSignIn,
    handleGoogleSignOut,
  };
};