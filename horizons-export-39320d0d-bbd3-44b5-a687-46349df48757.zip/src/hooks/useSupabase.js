import { useState, useCallback } from 'react';
import { initializeSupabaseClient, logActivity } from '@/services/supabaseService';
import { useLeadStore } from '@/store/leadStore';

export const useSupabase_hook = (toast, setGlobalLeadData, globalLeadData) => {
  const [isSupabaseConnected, setIsSupabaseConnected] = useState(false);
  const [uploadedCsvPath, setUploadedCsvPath] = useState('');
  const saveLeadsToSupabase = useLeadStore(state => state.saveLeadsToSupabase);
  const loadLeadsFromSupabase = useLeadStore(state => state.loadLeadsFromSupabase);

  const handleSupabaseInit = useCallback(() => {
    if (isSupabaseConnected) return;
    const { success } = initializeSupabaseClient();
    setIsSupabaseConnected(success);
    if (!success) {
       toast({ title: "Configuração Supabase Pendente", description: "Verifique suas variáveis de ambiente VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY.", variant: "warning", duration: 7000 });
    }
  }, [toast, isSupabaseConnected]);

  const handleUploadToSupabase = useCallback(async () => {
    if (!isSupabaseConnected) {
      toast({ title: "Supabase não conectado", variant: "destructive" });
      return;
    }
    if (!globalLeadData || globalLeadData.length === 0) {
      toast({ title: "Nenhum Lead para Enviar", description: "A base de leads no app está vazia.", variant: "warning" });
      return;
    }
    await saveLeadsToSupabase(globalLeadData);
  }, [isSupabaseConnected, toast, globalLeadData, saveLeadsToSupabase]);

  const handleLoadFromSupabase = useCallback(async () => {
    if (!isSupabaseConnected) {
      toast({ title: "Supabase não conectado", variant: "destructive" });
      return;
    }
    await loadLeadsFromSupabase();
  }, [isSupabaseConnected, loadLeadsFromSupabase]);

  const handleFileUploadToStorage = useCallback(async (file) => {
    if (!isSupabaseConnected) {
      toast({ title: "Supabase não conectado", variant: "destructive" });
      return null;
    }
    const { supabase } = initializeSupabaseClient();
    if (!file) {
      toast({ title: "Nenhum arquivo selecionado", variant: "warning" });
      return null;
    }

    const fileName = `${new Date().toISOString().replace(/[:.]/g, '-')}-${file.name.replace(/\s+/g, '_')}`;
    
    const fileToBase64 = (fileToConvert) => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(fileToConvert);
        reader.onload = () => resolve(reader.result.split(',')[1]);
        reader.onerror = error => reject(error);
    });

    try {
        toast({ title: "Preparando arquivo para envio...", description: `Arquivo: ${fileName}` });
        const fileContentBase64 = await fileToBase64(file);

        toast({ title: "Enviando arquivo...", description: `Invocando função para upload seguro.` });
        logActivity({ action_type: 'UPLOAD_CSV_FUNCTION', status: 'STARTED', details: { fileName } });

        const { data, error } = await supabase.functions.invoke('upload-csv-to-storage', {
          body: {
            fileName,
            fileContentBase64
          }
        });

        if (error) {
            throw new Error(error.message);
        }
        
        if (data.error) {
            throw new Error(data.error);
        }

        toast({ title: "Arquivo Enviado com Sucesso!", description: `Caminho: ${data.path}` });
        logActivity({ action_type: 'UPLOAD_CSV_FUNCTION', status: 'SUCCESS', details: { fileName, path: data.path } });
        setUploadedCsvPath(data.path);
        return data.path;

    } catch (e) {
        toast({ title: "Erro no Upload", description: e.message, variant: "destructive" });
        logActivity({ action_type: 'UPLOAD_CSV_FUNCTION', status: 'FAILURE', details: { fileName, error: e.message } });
        return null;
    }
  }, [isSupabaseConnected, toast, setUploadedCsvPath]);

  const handleProcessCsvFromStorage = useCallback(async (filePathFromInput) => {
    if (!isSupabaseConnected) {
      toast({ title: "Supabase não conectado", variant: "destructive" });
      return;
    }
    const { supabase } = initializeSupabaseClient();
    const pathToProcess = filePathFromInput || uploadedCsvPath;
    if (!pathToProcess) {
      toast({ title: "Caminho do Arquivo Necessário", description: "Faça upload de um arquivo ou insira o caminho.", variant: "warning" });
      return;
    }
    toast({ title: "Invocando Edge Function...", description: `Processando arquivo: ${pathToProcess}` });
    logActivity({ action_type: 'PROCESS_CSV_STORAGE', status: 'STARTED', details: { path: pathToProcess } });

    const { data, error } = await supabase.functions.invoke('process-lead-csv', {
      body: { filePath: pathToProcess },
    });
    if (error) {
      toast({ title: "Erro na Edge Function", description: error.message, variant: "destructive" });
      logActivity({ action_type: 'PROCESS_CSV_STORAGE', status: 'FAILURE', details: { path: pathToProcess, error: error.message } });
    } else {
      toast({ title: "Edge Function Concluída!", description: data.message || "Processamento finalizado." });
      logActivity({ action_type: 'PROCESS_CSV_STORAGE', status: 'SUCCESS', details: { path: pathToProcess, message: data.message } });
      await handleLoadFromSupabase(); 
    }
  }, [isSupabaseConnected, toast, uploadedCsvPath, handleLoadFromSupabase]);

  return {
    isSupabaseConnected,
    uploadedCsvPath,
    setUploadedCsvPath,
    handleSupabaseInit,
    handleUploadToSupabase,
    handleLoadFromSupabase,
    handleFileUploadToStorage,
    handleProcessCsvFromStorage,
  };
};