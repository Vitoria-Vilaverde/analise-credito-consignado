import { useState, useEffect, useCallback } from 'react';
import { initializeSupabaseClient, signOutUser } from '@/services/supabaseService';

export const useAuth = (toast) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(() => localStorage.getItem('activeTab') || 'resumo');
  const [session, setSession] = useState(null);

  useEffect(() => {
    const { supabase } = initializeSupabaseClient();
    if (!supabase) {
      setLoading(false);
      return;
    }

    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setSession(session);
      setIsLoggedIn(!!session);
      setLoading(false);
    };

    checkSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setIsLoggedIn(!!session);
    });

    return () => {
      subscription?.unsubscribe();
    };
  }, []);

  const handleLoginSuccess = () => {
    // This function is kept for compatibility with the App structure,
    // but the onAuthStateChange listener is now the source of truth for the login state.
    // It can be used to trigger additional actions upon successful login if needed.
  };

  const handleLogout = async () => {
    setLoading(true);
    await signOutUser();
    setActiveTabPersisted('resumo');
    setLoading(false);
  };

  const setActiveTabPersisted = useCallback((tab) => {
    localStorage.setItem('activeTab', tab);
    setActiveTab(tab);
  }, []);

  return {
    isLoggedIn,
    isLoading: loading,
    activeTab,
    handleLoginSuccess,
    handleLogout,
    setActiveTabPersisted,
    session,
  };
};