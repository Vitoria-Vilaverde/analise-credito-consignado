import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';

import ResumoBase from '@/components/ResumoBase';
import Segmentacao from '@/components/Segmentacao';
import GestaoClientes from '@/components/GestaoClientes';
import AtualizacaoMargens from '@/components/AtualizacaoMargens';
import NovaVidaTelefones from '@/components/NovaVidaTelefones';
import RegrasSegmentacao from '@/components/RegrasSegmentacao';
import AdministracaoUsuarios from '@/components/AdministracaoUsuarios';
import Login from '@/components/Login';
import Integracoes from '@/components/Integracoes';
import AnalisesAvancadas from '@/components/AnalisesAvancadas';
import ActivityLog from '@/components/ActivityLog';
import BaseCarregada from '@/components/BaseCarregada';

import { useAuth } from '@/hooks/useAuth';
import { useGoogleApi } from '@/hooks/useGoogleApi';
import { useLeadStore } from '@/store/leadStore';
import { useSupabase_hook } from '@/hooks/useSupabase';

import { AppHeader } from '@/components/layout/AppHeader';
import { Sidebar } from '@/components/layout/Sidebar';
import { MainContent } from '@/components/layout/MainContent';
import { menuItems } from '@/config/menuItems';

function App() {
  const { toast } = useToast();
  const { 
    isLoggedIn, 
    isLoading: isAuthLoading,
    activeTab, 
    handleLoginSuccess, 
    handleLogout: performLogout,
    setActiveTabPersisted 
  } = useAuth(toast);
  
  const leads = useLeadStore(state => state.leads);
  const isLeadsLoading = useLeadStore(state => state.isLoading);
  const loadLeadsFromSupabase = useLeadStore(state => state.loadLeadsFromSupabase);
  const setLeadsInStore = useLeadStore(state => state.setLeads);
  const syncLeadsFromGoogleSheet = useLeadStore(state => state.syncLeadsFromGoogleSheet);
  const handleLeadUploadFromFile = useLeadStore(state => state.handleLeadUploadFromFile);

  const { 
    isGoogleAuthReady, 
    isGoogleSignedIn, 
    handleGoogleSignIn, 
    handleGoogleSignOut 
  } = useGoogleApi(toast);

  const {
    isSupabaseConnected,
    uploadedCsvPath,
    setUploadedCsvPath,
    handleSupabaseInit,
    handleUploadToSupabase,
    handleLoadFromSupabase,
    handleFileUploadToStorage,
    handleProcessCsvFromStorage,
  } = useSupabase_hook(toast, setLeadsInStore, leads);

  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [salesData, setSalesData] = useState([]);

  useEffect(() => {
    handleSupabaseInit();
  }, [handleSupabaseInit]);

  useEffect(() => {
    const initializeAppData = async () => {
      if (isLoggedIn && isSupabaseConnected) {
        await loadLeadsFromSupabase();
      }
    };
    initializeAppData();
  }, [isLoggedIn, isSupabaseConnected, loadLeadsFromSupabase]);

  const handleSalesDataUpload = (file) => {
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target.result;
        try {
          const lines = text.split(/\r\n|\n/).filter(line => line.trim() !== '');
          if (lines.length < 2) {
            toast({ title: "Erro no CSV de Vendas", description: "Arquivo CSV precisa de cabeçalho e dados.", variant: "destructive" });
            return;
          }
          const delimiter = lines[0].includes(';') ? ';' : ',';
          const headerFromFile = lines[0].split(delimiter).map(h => String(h || '').trim().toUpperCase().replace(/\s+/g, '_').replace(/"/g, ''));
          const data = lines.slice(1).map(row => {
            let obj = {};
            const values = row.split(delimiter);
            headerFromFile.forEach((header, index) => {
              obj[header.toLowerCase()] = values[index] ? String(values[index]).trim().replace(/"/g, '') : '';
            });
            return obj;
          });
          setSalesData(data);
          localStorage.setItem('salesData', JSON.stringify(data));
          toast({ title: "Base de Vendas Importada!", description: `${data.length} registros de vendas carregados.` });
        } catch (error) {
          toast({ title: "Erro ao Processar CSV de Vendas", description: `Verifique o formato do arquivo. Detalhe: ${error.message}`, variant: "destructive" });
        }
      };
      reader.onerror = () => {
        toast({ title: "Erro de Leitura do CSV de Vendas", description: "Não foi possível ler o arquivo.", variant: "destructive" });
      };
      reader.readAsText(file, 'UTF-8');
    }
  };

  useEffect(() => {
    const storedSalesData = localStorage.getItem('salesData');
    if (storedSalesData) {
      try {
        setSalesData(JSON.parse(storedSalesData));
      } catch (e) {
        console.error("Erro ao carregar dados de vendas do localStorage:", e);
      }
    }
  }, []);

  const handleLogout = () => {
    performLogout();
    if (isGoogleSignedIn) {
      handleGoogleSignOut();
    }
  };

  const renderContent = () => {
    if (isAuthLoading) {
       return (
        <div className="flex flex-col items-center justify-center h-full min-h-screen text-white">
          <motion.div 
            animate={{ rotate: 360 }} 
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-16 h-16 border-t-4 border-b-4 border-purple-500 rounded-full mb-4"
          />
          <p className="text-xl">Verificando sessão...</p>
        </div>
      );
    }

    if (!isLoggedIn) {
      return <Login onLoginSuccess={handleLoginSuccess} />;
    }
    
    if (isLeadsLoading) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-white">
          <motion.div 
            animate={{ rotate: 360 }} 
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-16 h-16 border-t-4 border-b-4 border-purple-500 rounded-full mb-4"
          />
          <p className="text-xl">Carregando dados...</p>
        </div>
      );
    }

    const commonProps = { globalLeadData: leads };
    
    const integrationProps = { 
      isGoogleAuthReady, 
      isGoogleSignedIn, 
      handleGoogleSignIn, 
      handleGoogleSignOut, 
      handleSyncGoogleSheet: syncLeadsFromGoogleSheet,
      isSupabaseReady: isSupabaseConnected,
      onSupabaseConnect: handleSupabaseInit,
      onSupabaseUpload: handleUploadToSupabase,
      onSupabaseLoad: handleLoadFromSupabase,
      onFileUploadToStorage: handleFileUploadToStorage,
      uploadedCsvPathForCard: uploadedCsvPath,
      setUploadedCsvPathForCard: setUploadedCsvPath,
      onProcessCsvFromStorage: handleProcessCsvFromStorage,
    };
    
    switch (activeTab) {
      case 'resumo':
        return <ResumoBase {...commonProps} handleLeadUpload={handleLeadUploadFromFile} />;
      case 'base':
        return <BaseCarregada {...commonProps} />;
      case 'segmentacao':
        return <Segmentacao {...commonProps} />;
      case 'gestao':
        return <GestaoClientes {...commonProps} />;
      case 'margens':
        return <AtualizacaoMargens {...commonProps} />;
      case 'telefones':
        return <NovaVidaTelefones {...commonProps} />;
      case 'regras':
        return <RegrasSegmentacao {...commonProps} />;
      case 'analises':
        return <AnalisesAvancadas {...commonProps} salesData={salesData} handleSalesDataUpload={handleSalesDataUpload} />;
      case 'usuarios':
        return <AdministracaoUsuarios />;
      case 'integracoes':
        return <Integracoes {...integrationProps} />;
      case 'logs':
        return <ActivityLog />;
      default:
        return <ResumoBase {...commonProps} handleLeadUpload={handleLeadUploadFromFile} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <Toaster />
      
      <AppHeader 
        isLoggedIn={isLoggedIn}
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
        onLogout={handleLogout}
        toast={toast}
      />

      <div className="flex">
        {isLoggedIn && (
          <Sidebar 
            sidebarOpen={sidebarOpen}
            activeTab={activeTab}
            handleTabChange={setActiveTabPersisted}
            menuItems={menuItems}
          />
        )}

        <MainContent 
          isLoggedIn={isLoggedIn}
          sidebarOpen={sidebarOpen}
          activeTab={activeTab}
          menuItems={menuItems}
          renderContent={renderContent}
        />
      </div>
    </div>
  );
}

export default App;