import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { LogIn, CloudCog, CheckCircle, XCircle, AlertTriangle, Info, LogOut, FileSpreadsheet, Database } from 'lucide-react';

const GoogleSheetsIntegrationCard = ({ config, ...props }) => {
  const { 
    title, 
    description, 
    icon: Icon, 
    status, 
    onConnect, 
    onDisconnect,
    onSyncToApp,
    isGoogleAuthReady 
  } = config;

  const { toast } = useToast();
  const [sheetIdInput, setSheetIdInput] = useState('');
  const [rangeInput, setRangeInput] = useState('A1:Z1000'); 
  const [currentStatus, setCurrentStatus] = useState(status);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    setCurrentStatus(props.isGoogleSignedIn);
  }, [props.isGoogleSignedIn]);

  const handleConnectAction = async () => {
    if (!onConnect) {
      toast({ 
        title: "Erro de Configuração", 
        description: "Função de conexão não configurada.", 
        variant: "destructive" 
      });
      return;
    }

    setIsProcessing(true);
    try {
      await onConnect();
    } catch (error) {
      console.error('Erro ao conectar:', error);
      toast({ 
        title: "Erro na Conexão", 
        description: "Falha ao conectar com Google.", 
        variant: "destructive" 
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSyncAction = async () => {
    if (!sheetIdInput.trim()) {
      toast({ 
        title: "ID Obrigatório", 
        description: "Por favor, insira o ID da planilha.", 
        variant: "destructive" 
      });
      return;
    }

    if (!onSyncToApp) {
      toast({ 
        title: "Erro de Configuração", 
        description: "Função de sincronização não configurada.", 
        variant: "destructive" 
      });
      return;
    }

    setIsProcessing(true);
    try {
      await onSyncToApp(sheetIdInput, rangeInput);
    } catch (error) {
      console.error('Erro na sincronização:', error);
      toast({ 
        title: "Erro na Sincronização", 
        description: "Falha ao sincronizar dados.", 
        variant: "destructive" 
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDisconnectAction = () => {
    if (onDisconnect) {
      onDisconnect();
      setCurrentStatus(false);
    }
  };
  
  let statusText = 'Não Conectado';
  let statusColor = 'text-yellow-400';
  let StatusIconComponent = AlertTriangle;

  if (currentStatus === true) {
    statusText = 'Conectado';
    statusColor = 'text-green-400';
    StatusIconComponent = CheckCircle;
  } else if (isGoogleAuthReady === false) {
    statusText = 'Carregando API...';
    statusColor = 'text-orange-400';
    StatusIconComponent = CloudCog;
  } else {
    StatusIconComponent = XCircle;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-effect rounded-xl p-6 flex flex-col justify-between card-hover min-h-[500px]" 
    >
      <div>
        <div className="flex items-center gap-4 mb-4">
          <div className="p-3 bg-white/10 rounded-lg">
            <Icon className="h-6 w-6 text-blue-400" />
          </div>
          <h3 className="text-xl font-semibold text-white">{title}</h3>
        </div>
        
        <p className="text-gray-300 text-sm mb-4">{description}</p>
        
        <div className="bg-slate-800/50 p-4 rounded-lg mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Info size={16} className="text-blue-400" />
            <span className="text-sm font-medium text-blue-400">Como usar:</span>
          </div>
          <ul className="text-xs text-slate-300 space-y-1">
            <li>1. Clique em "Conectar ao Google" para autenticar</li>
            <li>2. Insira o ID da sua planilha Google Sheets</li>
            <li>3. Defina o intervalo de células (ex: A1:Z1000)</li>
            <li>4. Clique em "Sincronizar Planilha" para importar</li>
            <li>5. Os dados serão salvos localmente no navegador</li>
          </ul>
        </div>

        <div className="space-y-4 mb-6">
          <div>
            <Label htmlFor="sheetId" className="text-slate-300 mb-2 block text-sm flex items-center">
              <FileSpreadsheet size={14} className="mr-1.5" /> 
              ID da Planilha Google Sheets
            </Label>
            <Input
              id="sheetId"
              placeholder="Ex: 1aBcDeFgHiJkLmNoPqRsTuVwXy..."
              value={sheetIdInput}
              onChange={(e) => setSheetIdInput(e.target.value)}
              className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-blue-500"
              disabled={isProcessing}
            />
            <p className="text-xs text-slate-400 mt-1">
              Encontre o ID na URL da planilha: docs.google.com/spreadsheets/d/[ID]/edit
            </p>
          </div>
          
          <div>
            <Label htmlFor="range" className="text-slate-300 mb-2 block text-sm flex items-center">
              <Database size={14} className="mr-1.5" />
              Intervalo de Células
            </Label>
            <Input
              id="range"
              placeholder="Ex: A1:Z1000"
              value={rangeInput}
              onChange={(e) => setRangeInput(e.target.value)}
              className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:border-blue-500"
              disabled={isProcessing}
            />
            <p className="text-xs text-slate-400 mt-1">
              Formato: NomeAba!A1:Z1000 ou apenas A1:Z1000 para primeira aba
            </p>
          </div>
        </div>
      </div>
      
      <div className="mt-auto space-y-3">
        {!currentStatus ? (
          <Button
            className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            onClick={handleConnectAction}
            disabled={!isGoogleAuthReady || isProcessing}
          >
            <LogIn className="h-4 w-4 mr-2" /> 
            {isProcessing ? 'Conectando...' : 'Conectar ao Google'}
          </Button>
        ) : (
          <>
            <Button
              className="w-full bg-green-600 hover:bg-green-700 text-white"
              onClick={handleSyncAction}
              disabled={!sheetIdInput.trim() || isProcessing}
            >
              <FileSpreadsheet className="h-4 w-4 mr-2" /> 
              {isProcessing ? 'Sincronizando...' : 'Sincronizar Planilha'}
            </Button>
            
            <Button
              variant="outline"
              className="w-full border-red-500/50 text-red-400 hover:bg-red-500/10"
              onClick={handleDisconnectAction}
              disabled={isProcessing}
            >
              <LogOut className="h-4 w-4 mr-2" /> 
              Desconectar do Google
            </Button>
          </>
        )}
        
        <div className={`text-xs text-center flex items-center justify-center gap-2 ${statusColor} p-2 bg-slate-800/30 rounded`}>
          <StatusIconComponent className="h-4 w-4" /> 
          <span>Status: {statusText}</span>
        </div>
      </div>
    </motion.div>
  );
};

export default GoogleSheetsIntegrationCard;