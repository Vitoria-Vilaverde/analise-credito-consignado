import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { UploadCloud, DownloadCloud, FileUp, PlayCircle, LogIn, CheckCircle, XCircle, AlertTriangle, CloudCog } from 'lucide-react';

const SupabaseIntegrationCard = ({ config, ...props }) => {
  const {
    title,
    description,
    icon: Icon,
    status,
    onConnect,
    onUpload,
    onLoad,
    onFileUploadToStorage,
    onProcessCsvFromStorage,
    uploadedCsvPathForCard,
    setUploadedCsvPathForCard,
    isSupabaseReady,
  } = config;
  
  const { toast } = useToast();
  const fileInputRef = useRef(null);
  const [localFilePath, setLocalFilePath] = useState('');

  useEffect(() => {
    if (uploadedCsvPathForCard) {
      setLocalFilePath(uploadedCsvPathForCard);
    }
  }, [uploadedCsvPathForCard]);

  const handleAction = (actionFn, defaultMessage, actionName, requiresAuthCheck = false, authReadyState = false) => {
    if (requiresAuthCheck && (authReadyState === false || authReadyState === undefined)) {
      toast({
        title: `API de ${title.split(' ')[0]} não pronta`,
        description: `Aguarde a inicialização da API de ${title.split(' ')[0]} e tente novamente.`,
        variant: "destructive"
      });
      return;
    }
    
    if (actionFn) {
      actionFn();
    } else {
      toast({
        title: "🚧 Funcionalidade em desenvolvimento",
        description: defaultMessage || `${actionName || 'Esta funcionalidade'} ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀`
      });
    }
  };
  
  const handleFileSelectAndUpload = async (event) => {
    const file = event.target.files[0];
    if (file && onFileUploadToStorage) {
      const path = await onFileUploadToStorage(file);
      if (path && setUploadedCsvPathForCard) {
        setUploadedCsvPathForCard(path);
        setLocalFilePath(path);
      }
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  let statusText = 'Não Conectado';
  let statusColor = 'text-yellow-400';
  let StatusIconComponent = AlertTriangle;

  if (status === true || status === 'connected') {
    statusText = 'Conectado';
    statusColor = 'text-green-400';
    StatusIconComponent = CheckCircle;
  } else if (isSupabaseReady === false && status !== 'not_ready') {
    statusText = 'Supabase Carregando...';
    statusColor = 'text-orange-400';
    StatusIconComponent = CloudCog;
  } else if (status === 'not_ready') {
    statusText = 'Config. Pendente';
    statusColor = 'text-red-500';
    StatusIconComponent = XCircle;
  } else {
    StatusIconComponent = XCircle;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-effect rounded-xl p-6 flex flex-col justify-between card-hover min-h-[380px]"
    >
      <div>
        <div className="flex items-center gap-4 mb-3">
          <div className="p-3 bg-white/10 rounded-lg">
            <Icon className="h-6 w-6 text-blue-400" />
          </div>
          <h3 className="text-xl font-semibold text-white">{title}</h3>
        </div>
        <p className="text-gray-300 text-sm mb-4">{description}</p>
      </div>
      <div className="mt-auto space-y-2">
        <Button
          className="w-full bg-sky-600 hover:bg-sky-700"
          onClick={() => handleAction(onUpload, "Upload de Dados para Supabase", "Upload Supabase", true, isSupabaseReady)}
          disabled={!isSupabaseReady}
        >
          <UploadCloud className="h-4 w-4 mr-2" />
          Enviar Leads (App) para Supabase
        </Button>
        <Button
          className="w-full bg-emerald-600 hover:bg-emerald-700"
          onClick={() => handleAction(onLoad, "Carregar Dados do Supabase", "Carregar Supabase", true, isSupabaseReady)}
          disabled={!isSupabaseReady}
        >
          <DownloadCloud className="h-4 w-4 mr-2" />
          Carregar Leads do Supabase (para App)
        </Button>

        <div className="pt-2 border-t border-slate-700/50">
          <Label htmlFor={`file-upload-${title.replace(/\s+/g, '-')}`} className="text-sm font-medium text-slate-300 mb-1 block">
            Upload de CSV Grande (via Storage):
          </Label>
          <Button
            className="w-full bg-indigo-600 hover:bg-indigo-700"
            onClick={() => fileInputRef.current && fileInputRef.current.click()}
            disabled={!isSupabaseReady}
          >
            <FileUp className="h-4 w-4 mr-2" /> Selecionar CSV para Storage
          </Button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelectAndUpload}
            className="hidden"
            accept=".csv"
            id={`file-upload-${title.replace(/\s+/g, '-')}`}
          />
        </div>

        <Input
          type="text"
          placeholder="Caminho do arquivo no Storage"
          value={localFilePath}
          onChange={(e) => {
            setLocalFilePath(e.target.value);
            if (setUploadedCsvPathForCard) setUploadedCsvPathForCard(e.target.value);
          }}
          className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
          disabled={!isSupabaseReady}
        />
        <Button
          className="w-full bg-teal-600 hover:bg-teal-700"
          onClick={() => onProcessCsvFromStorage && onProcessCsvFromStorage(localFilePath)}
          disabled={!isSupabaseReady || !localFilePath}
        >
          <PlayCircle className="h-4 w-4 mr-2" /> Processar CSV do Storage
        </Button>

        {!isSupabaseReady && status !== 'not_ready' && (
          <Button
            className="w-full bg-purple-600 hover:bg-purple-700 mt-2"
            onClick={() => handleAction(onConnect, "Conectar ao Supabase", "Conectar Supabase")}
          >
            <LogIn className="h-4 w-4 mr-2" /> Conectar ao Supabase
          </Button>
        )}
        {status === 'not_ready' && (
          <p className="text-xs text-center text-red-400 mt-2">Configure as variáveis de ambiente do Supabase.</p>
        )}
        <p className={`mt-3 text-xs text-center flex items-center justify-center gap-1 ${statusColor}`}>
          <StatusIconComponent className="h-3 w-3" /> Status: {statusText}
        </p>
      </div>
    </motion.div>
  );
};

export default SupabaseIntegrationCard;