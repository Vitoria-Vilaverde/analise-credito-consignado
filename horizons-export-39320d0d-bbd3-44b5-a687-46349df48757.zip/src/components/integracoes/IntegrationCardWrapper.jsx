import React from 'react';
import GoogleSheetsIntegrationCard from '@/components/integracoes/GoogleSheetsIntegrationCard';
import SupabaseIntegrationCard from '@/components/integracoes/SupabaseIntegrationCard';
import GenericIntegrationPlaceholderCard from '@/components/integracoes/GenericIntegrationPlaceholderCard';

const IntegrationCardWrapper = ({ config, ...props }) => {
  switch (config.type) {
    case 'google-sheets':
      return <GoogleSheetsIntegrationCard config={config} {...props} />;
    case 'supabase':
      return <SupabaseIntegrationCard config={config} {...props} />;
    case 'generic':
    default:
      return <GenericIntegrationPlaceholderCard config={config} {...props} />;
  }
};

export default IntegrationCardWrapper;