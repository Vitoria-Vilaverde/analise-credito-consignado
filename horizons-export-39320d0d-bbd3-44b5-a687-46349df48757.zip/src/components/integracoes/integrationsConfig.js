import { FileSpreadsheet, Briefcase, Database, UploadCloud } from 'lucide-react';

export const getIntegrationsConfig = (props) => {
  const {
    isGoogleSignedIn,
    handleGoogleSignIn,
    handleGoogleSignOut,
    handleSyncGoogleSheet,
    isGoogleAuthReady,
    isSupabaseReady,
    onSupabaseConnect,
    onSupabaseUpload,
    onSupabaseLoad,
    onFileUploadToStorage,
    uploadedCsvPathForCard,
    setUploadedCsvPathForCard,
    onProcessCsvFromStorage,
  } = props;

  const integrations = [
    {
      id: 'google-sheets',
      type: 'google-sheets',
      title: 'Google Sheets API',
      description: 'Sincronize sua base de leads de uma planilha Google Sheets diretamente para o Supabase.',
      icon: FileSpreadsheet,
      status: isGoogleSignedIn,
      onConnect: handleGoogleSignIn,
      onDisconnect: handleGoogleSignOut,
      onSyncToApp: handleSyncGoogleSheet,
      isGoogleAuthReady: isGoogleAuthReady,
      requiresSheetId: true,
    },
    {
      id: 'supabase',
      type: 'supabase',
      title: 'Supabase DB',
      description: 'Gerencie seus leads diretamente no Supabase. Envie, carregue ou processe arquivos CSV grandes.',
      icon: UploadCloud,
      status: isSupabaseReady,
      onConnect: onSupabaseConnect,
      onUpload: onSupabaseUpload,
      onLoad: onSupabaseLoad,
      onFileUploadToStorage: onFileUploadToStorage,
      uploadedCsvPathForCard: uploadedCsvPathForCard,
      setUploadedCsvPathForCard: setUploadedCsvPathForCard,
      onProcessCsvFromStorage: onProcessCsvFromStorage,
      isSupabaseReady: isSupabaseReady,
    },
    {
      id: 'nova-vida',
      type: 'generic',
      title: 'Nova Vida API',
      description: 'Sincronize e atualize informações de contato dos leads diretamente com a plataforma Nova Vida.',
      icon: Briefcase,
      status: 'not_connected',
    },
  ];

  return integrations;
};