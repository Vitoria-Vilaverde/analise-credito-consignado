import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

const GenericIntegrationPlaceholderCard = ({ config, ...props }) => {
  const { title, description, icon: Icon, status } = config;

  let statusText = 'Não Conectado';
  let statusColor = 'text-yellow-400';
  let StatusIconComponent = AlertTriangle;

  if (status === true || status === 'connected') {
    statusText = 'Conectado';
    statusColor = 'text-green-400';
    StatusIconComponent = CheckCircle;
  } else {
    StatusIconComponent = XCircle;
  }
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-effect rounded-xl p-6 flex flex-col justify-between card-hover min-h-[380px]"
    >
      <div>
        <div className="flex items-center gap-4 mb-3">
          <div className="p-3 bg-white/10 rounded-lg">
            <Icon className="h-6 w-6 text-blue-400" />
          </div>
          <h3 className="text-xl font-semibold text-white">{title}</h3>
        </div>
        <p className="text-gray-300 text-sm mb-4">{description}</p>
      </div>
      <div className="mt-auto space-y-2">
        <Button
          className="w-full bg-gray-600 hover:bg-gray-700"
          onClick={() => 
            props.toast && props.toast({
              title: "🚧 Funcionalidade em desenvolvimento",
              description: "Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
            })
          }
        >
          Conectar (Em Breve)
        </Button>
        <p className={`mt-3 text-xs text-center flex items-center justify-center gap-1 ${statusColor}`}>
          <StatusIconComponent className="h-3 w-3" /> Status: {statusText}
        </p>
      </div>
    </motion.div>
  );
};

export default GenericIntegrationPlaceholderCard;