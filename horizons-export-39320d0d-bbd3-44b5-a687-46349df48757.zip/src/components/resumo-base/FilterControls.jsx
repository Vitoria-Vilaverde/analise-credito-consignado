import React from 'react';
import { Filter, Upload, Download, DollarSign, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input'; 
import { MegaphoneOff as SpeakerOff, AlertTriangle } from 'lucide-react';

const FilterControls = ({ filters, setFilters, handleApplyFilters, handleFileUpload, handleExportData, fileInputRef }) => {
  const handleNumericFilterChange = (filterName, subKey, value) => {
    const numericValue = value === '' ? '' : parseFloat(value);
    setFilters(prev => ({
      ...prev,
      [filterName]: {
        ...prev[filterName],
        [subKey]: numericValue,
      }
    }));
  };

  return (
    <div className="glass-effect rounded-xl p-6">
      <div className="flex items-center gap-4 mb-6">
        <Filter className="h-6 w-6 text-blue-400" />
        <h3 className="text-xl font-semibold text-white">Filtros Avançados</h3>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-6">
        <div>
          <Label htmlFor="banco-filter" className="block text-sm font-medium text-gray-300 mb-1.5">Banco</Label>
          <select 
            id="banco-filter"
            className="w-full px-3 py-2.5 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
            value={filters.banco}
            onChange={(e) => setFilters({...filters, banco: e.target.value})}
          >
            <option value="todos">Todos os Bancos</option>
            <option value="banco-master">Banco Master</option>
            <option value="banco-do-brasil">Banco do Brasil</option>
            <option value="caixa">Caixa</option>
            <option value="bradesco">Bradesco</option>
            <option value="itau">Itaú</option>
          </select>
        </div>
        
        <div>
          <Label htmlFor="convenio-filter" className="block text-sm font-medium text-gray-300 mb-1.5">Convênio</Label>
          <select 
            id="convenio-filter"
            className="w-full px-3 py-2.5 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
            value={filters.convenio}
            onChange={(e) => setFilters({...filters, convenio: e.target.value})}
          >
            <option value="todos">Todos os Convênios</option>
            <option value="inss">INSS</option>
            <option value="siape">SIAPE</option>
            <option value="estadual">Estadual</option>
          </select>
        </div>

        <div>
          <Label htmlFor="produto-filter" className="block text-sm font-medium text-gray-300 mb-1.5">Produto</Label>
          <select 
            id="produto-filter"
            className="w-full px-3 py-2.5 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
            value={filters.produto}
            onChange={(e) => setFilters({...filters, produto: e.target.value})}
          >
            <option value="todos">Todos os Produtos</option>
            <option value="cartão">Cartão</option>
            <option value="empréstimo">Empréstimo</option>
            <option value="saque">Saque</option>
          </select>
        </div>
        
        <div className="flex flex-col space-y-3">
          <Label className="block text-sm font-medium text-gray-300">Opções Adicionais</Label>
          <div className="flex items-center space-x-3">
            <Checkbox 
              id="nao-perturbe" 
              checked={filters.naoPerturbe} 
              onCheckedChange={(checked) => setFilters({...filters, naoPerturbe: checked})} 
              className="border-gray-400 data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
            />
            <Label htmlFor="nao-perturbe" className="text-sm text-gray-300 flex items-center gap-1.5 cursor-pointer"><SpeakerOff size={16}/> Não Perturbe</Label>
          </div>
          <div className="flex items-center space-x-3">
            <Checkbox 
              id="negativados" 
              checked={filters.negativados} 
              onCheckedChange={(checked) => setFilters({...filters, negativados: checked})} 
              className="border-gray-400 data-[state=checked]:bg-red-500 data-[state=checked]:border-red-500" 
            />
            <Label htmlFor="negativados" className="text-sm text-gray-300 flex items-center gap-1.5 cursor-pointer"><AlertTriangle size={16}/> Negativados</Label>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <div className="flex items-center mb-2">
            <Checkbox 
              id="filtro-margem" 
              checked={filters.margem.ativo} 
              onCheckedChange={(checked) => setFilters(prev => ({...prev, margem: {...prev.margem, ativo: checked}}))}
              className="border-gray-400 data-[state=checked]:bg-green-500 data-[state=checked]:border-green-500"
            />
            <Label htmlFor="filtro-margem" className="ml-2 text-sm font-medium text-gray-300 flex items-center gap-1.5 cursor-pointer"><DollarSign size={16}/> Filtrar por Margem (Limite Disponível)</Label>
          </div>
          {filters.margem.ativo && (
            <div className="grid grid-cols-2 gap-3 pl-6">
              <div>
                <Label htmlFor="margem-min" className="block text-xs text-gray-400 mb-1">Mínimo</Label>
                <Input 
                  type="number" 
                  id="margem-min" 
                  placeholder="Ex: 100"
                  value={filters.margem.min === null ? '' : filters.margem.min}
                  onChange={(e) => handleNumericFilterChange('margem', 'min', e.target.value)}
                  className="w-full bg-white/10 border-white/20"
                />
              </div>
              <div>
                <Label htmlFor="margem-max" className="block text-xs text-gray-400 mb-1">Máximo</Label>
                <Input 
                  type="number" 
                  id="margem-max" 
                  placeholder="Ex: 1000"
                  value={filters.margem.max === null ? '' : filters.margem.max}
                  onChange={(e) => handleNumericFilterChange('margem', 'max', e.target.value)}
                  className="w-full bg-white/10 border-white/20"
                />
              </div>
            </div>
          )}
        </div>

        <div>
          <div className="flex items-center mb-2">
            <Checkbox 
              id="filtro-saque" 
              checked={filters.saque.ativo} 
              onCheckedChange={(checked) => setFilters(prev => ({...prev, saque: {...prev.saque, ativo: checked}}))}
              className="border-gray-400 data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500"
            />
            <Label htmlFor="filtro-saque" className="ml-2 text-sm font-medium text-gray-300 flex items-center gap-1.5 cursor-pointer"><CreditCard size={16}/> Filtrar por Saque (Cesta)</Label>
          </div>
          {filters.saque.ativo && (
            <div className="grid grid-cols-2 gap-3 pl-6">
              <div>
                <Label htmlFor="saque-min" className="block text-xs text-gray-400 mb-1">Mínimo</Label>
                <Input 
                  type="number" 
                  id="saque-min" 
                  placeholder="Ex: 50"
                  value={filters.saque.min === null ? '' : filters.saque.min}
                  onChange={(e) => handleNumericFilterChange('saque', 'min', e.target.value)}
                  className="w-full bg-white/10 border-white/20"
                />
              </div>
              <div>
                <Label htmlFor="saque-max" className="block text-xs text-gray-400 mb-1">Máximo</Label>
                <Input 
                  type="number" 
                  id="saque-max" 
                  placeholder="Ex: 500"
                  value={filters.saque.max === null ? '' : filters.saque.max}
                  onChange={(e) => handleNumericFilterChange('saque', 'max', e.target.value)}
                  className="w-full bg-white/10 border-white/20"
                />
              </div>
            </div>
          )}
        </div>
      </div>
      
      <div className="flex flex-wrap gap-4 items-center">
        <Button 
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg transition-all transform hover:scale-105"
          onClick={handleApplyFilters}
        >
          <Filter className="h-4 w-4 mr-2" />
          Aplicar Filtros
        </Button>
        <Button 
          variant="outline" 
          className="border-green-500/70 text-green-400 hover:bg-green-500/10 hover:text-green-300 transition-colors"
          onClick={() => fileInputRef.current && fileInputRef.current.click()}
        >
          <Upload className="h-4 w-4 mr-2" />
          Importar CSV
        </Button>
        <input type="file" accept=".csv" ref={fileInputRef} onChange={handleFileUpload} className="hidden" />
        <Button 
          variant="outline" 
          className="border-orange-500/70 text-orange-400 hover:bg-orange-500/10 hover:text-orange-300 transition-colors"
          onClick={handleExportData}
        >
          <Download className="h-4 w-4 mr-2" />
          Exportar CSV (Filtrados)
        </Button>
      </div>
    </div>
  );
};

export default FilterControls;