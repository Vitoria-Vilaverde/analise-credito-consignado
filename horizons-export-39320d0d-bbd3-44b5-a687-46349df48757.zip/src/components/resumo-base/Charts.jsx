import React from 'react';
import { motion } from 'framer-motion';
import { BarChart3, PieChart, Activity } from 'lucide-react';
import { Bar, Pie, Line } from 'react-chartjs-2';

const Charts = ({ bancoData, estadoData, idadeData, rendaData, chartOptions, pieOptions, filteredDataPresent }) => {
  const chartContainerVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.4 } }
  };
  const chartContainerVariantsRight = {
    hidden: { opacity: 0, x: 20 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.4 } }
  };

  const NoDataMessage = () => (
    <p className="text-gray-400 text-center mt-10 text-lg">Sem dados para exibir com os filtros atuais. 📊</p>
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <motion.div
        variants={chartContainerVariants}
        initial="hidden"
        animate="visible"
        className="chart-container p-6 h-[450px]"
      >
        <div className="flex items-center gap-3 mb-4">
          <BarChart3 className="h-6 w-6 text-blue-400" />
          <h3 className="text-xl font-semibold text-white">Distribuição por Banco</h3>
        </div>
        {filteredDataPresent ? <Bar data={bancoData} options={chartOptions} /> : <NoDataMessage />}
      </motion.div>

      <motion.div
        variants={chartContainerVariantsRight}
        initial="hidden"
        animate="visible"
        className="chart-container p-6 h-[450px]"
      >
        <div className="flex items-center gap-3 mb-4">
          <BarChart3 className="h-6 w-6 text-purple-400" />
          <h3 className="text-xl font-semibold text-white">Leads por Estado</h3>
        </div>
        {filteredDataPresent ? <Bar data={estadoData} options={chartOptions} /> : <NoDataMessage />}
      </motion.div>

      <motion.div
        variants={chartContainerVariants}
        initial="hidden"
        animate="visible"
        transition={{ delay: 0.1 }}
        className="chart-container p-6 h-[450px]"
      >
        <div className="flex items-center gap-3 mb-4">
          <PieChart className="h-6 w-6 text-green-400" />
          <h3 className="text-xl font-semibold text-white">Faixa Etária</h3>
        </div>
        {filteredDataPresent ? <Pie data={idadeData} options={pieOptions} /> : <NoDataMessage />}
      </motion.div>

      <motion.div
        variants={chartContainerVariantsRight}
        initial="hidden"
        animate="visible"
        transition={{ delay: 0.1 }}
        className="chart-container p-6 h-[450px]"
      >
        <div className="flex items-center gap-3 mb-4">
          <Activity className="h-6 w-6 text-orange-400" />
          <h3 className="text-xl font-semibold text-white">Evolução da Renda (Exemplo)</h3>
        </div>
        {filteredDataPresent ? <Line data={rendaData} options={chartOptions} /> : <NoDataMessage />}
      </motion.div>
    </div>
  );
};

export default Charts;