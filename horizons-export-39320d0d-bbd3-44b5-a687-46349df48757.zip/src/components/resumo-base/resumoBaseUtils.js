export const initialLeadData = [
  { id: 1, nome: 'João Silva', banco: 'Banco Master', convenio: 'INSS', margem: 500, perfil: 'tomador', produto: 'Empréstimo', nao_perturbe: false, negativado: false, limite_disponivel: 500, saque_cred_cesta: 200, estado: 'SP', idade: 45, renda: 3500 },
  { id: 2, nome: 'Maria Oliveira', banco: 'Banco do Brasil', convenio: 'SIAPE', margem: 0, perfil: 'nao-tomador', produto: 'Cartão', nao_perturbe: true, negativado: false, limite_disponivel: 0, saque_cred_cesta: 0, estado: 'RJ', idade: 30, renda: 4200 },
  { id: 3, nome: 'Carlos Santos', banco: 'Caixa', convenio: 'Estadual', margem: 1200, perfil: 'tomador', produto: 'Saque', nao_perturbe: false, negativado: true, limite_disponivel: -100, saque_cred_cesta: 1200, estado: 'MG', idade: 55, renda: 2800 },
  { id: 4, nome: 'Ana Pereira', banco: 'Banco Master', convenio: 'INSS', margem: 200, perfil: 'nao-tomador', produto: 'Empréstimo', nao_perturbe: false, negativado: false, limite_disponivel: 200, saque_cred_cesta: 50, estado: 'SP', idade: 62, renda: 1800 },
  { id: 5, nome: 'Paulo Costa', banco: 'Bradesco', convenio: 'SIAPE', margem: 800, perfil: 'tomador', produto: 'Cartão', nao_perturbe: false, negativado: false, limite_disponivel: 800, saque_cred_cesta: 300, estado: 'RS', idade: 38, renda: 5500 },
  { id: 6, nome: 'Julia Lima', banco: 'Itaú', convenio: 'INSS', margem: 0, perfil: 'nao-tomador', produto: 'Saque', nao_perturbe: true, negativado: true, limite_disponivel: 30, saque_cred_cesta: -50, estado: 'PR', idade: 28, renda: 2200 },
];

export const processChartData = (data, key, label) => {
  const counts = data.reduce((acc, lead) => {
    const value = lead[key] !== undefined && lead[key] !== null ? lead[key].toString() : 'Não Definido';
    acc[value] = (acc[value] || 0) + 1;
    return acc;
  }, {});
  return {
    labels: Object.keys(counts),
    datasets: [{
      label: label,
      data: Object.values(counts),
      backgroundColor: [
        'rgba(59, 130, 246, 0.85)', 'rgba(16, 185, 129, 0.85)', 'rgba(245, 158, 11, 0.85)', 
        'rgba(239, 68, 68, 0.85)', 'rgba(139, 92, 246, 0.85)', 'rgba(236, 72, 153, 0.85)',
        'rgba(14, 165, 233, 0.85)', 'rgba(244, 114, 182, 0.85)'
      ],
      borderColor: [
        'rgba(59, 130, 246, 1)', 'rgba(16, 185, 129, 1)', 'rgba(245, 158, 11, 1)', 
        'rgba(239, 68, 68, 1)', 'rgba(139, 92, 246, 1)', 'rgba(236, 72, 153, 1)',
        'rgba(14, 165, 233, 1)', 'rgba(244, 114, 182, 1)'
      ],
      borderWidth: 1.5,
      borderRadius: 5,
      hoverBorderWidth: 2.5,
      hoverBorderColor: '#fff'
    }]
  };
};

export const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'bottom',
      labels: { 
        color: '#CBD5E1', 
        font: { size: 13, family: "'Inter', sans-serif" },
        padding: 20,
        usePointStyle: true,
        pointStyle: 'rectRounded'
      } 
    },
    tooltip: {
      enabled: true,
      backgroundColor: 'rgba(0,0,0,0.8)',
      titleFont: { size: 14, family: "'Inter', sans-serif", weight: 'bold' },
      bodyFont: { size: 12, family: "'Inter', sans-serif" },
      padding: 10,
      cornerRadius: 6,
      displayColors: true,
      borderColor: 'rgba(255,255,255,0.2)',
      borderWidth: 1
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      ticks: { color: '#9CA3AF', font: { family: "'Inter', sans-serif" } },
      grid: { color: 'rgba(255,255,255,0.08)'}
    },
    x: {
      ticks: { color: '#9CA3AF', font: { family: "'Inter', sans-serif" } },
      grid: { color: 'rgba(255,255,255,0.08)'}
    }
  },
  animation: {
    duration: 600,
    easing: 'easeInOutQuart'
  }
};

export const pieOptions = {
  ...chartOptions,
  plugins: {
    ...chartOptions.plugins,
    legend: {
      position: 'right',
      labels: { 
        color: '#CBD5E1',
        font: { size: 13, family: "'Inter', sans-serif" },
        padding: 15,
        usePointStyle: true,
        pointStyle: 'circle'
      }
    },
  },
};

export const rendaDataExample = {
  labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
  datasets: [{
    label: 'Renda Média (R$)',
    data: [2800, 3200, 3100, 3400, 3600, 3800],
    borderColor: 'rgba(59, 130, 246, 1)',
    backgroundColor: 'rgba(59, 130, 246, 0.2)',
    tension: 0.4,
    fill: true,
    pointBackgroundColor: 'rgba(59, 130, 246, 1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(59, 130, 246, 1)',
    pointRadius: 4,
    pointHoverRadius: 7
  }]
};