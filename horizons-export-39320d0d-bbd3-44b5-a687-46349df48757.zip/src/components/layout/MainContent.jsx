import React from 'react';
import { motion } from 'framer-motion';
import { BarChart3, LogIn } from 'lucide-react';

export const MainContent = ({ isLoggedIn, sidebarOpen, activeTab, menuItems, renderContent }) => {
  const currentMenuItem = isLoggedIn ? menuItems.find(item => item.id === activeTab) : null;
  const displayLabel = isLoggedIn ? (currentMenuItem ? currentMenuItem.label : 'Resumo da Base') : 'Login';
  const displayIcon = isLoggedIn ? (currentMenuItem ? currentMenuItem.icon : BarChart3) : LogIn;
  const displayColor = isLoggedIn ? (currentMenuItem ? currentMenuItem.color : 'text-blue-400') : 'text-gray-400';

  return (
    <main className={`flex-1 transition-all duration-300 ${sidebarOpen && isLoggedIn ? 'ml-80' : 'ml-0'} pt-[calc(68px+1.5rem)]`}>
      <div className="p-6">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
             {React.createElement(displayIcon, { className: `h-6 w-6 ${displayColor}` })}
            <h2 className="text-2xl font-bold text-white">{displayLabel}</h2>
          </div>
          <div className="h-1 w-20 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full"></div>
        </div>

        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="animate-fade-in"
        >
          {renderContent()}
        </motion.div>
      </div>
    </main>
  );
};