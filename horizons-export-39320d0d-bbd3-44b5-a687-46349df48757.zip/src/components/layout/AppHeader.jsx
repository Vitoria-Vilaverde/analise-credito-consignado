import React from 'react';
import { Button } from '@/components/ui/button';
import { Database, Bell, Menu, X, LogOut } from 'lucide-react';

export const AppHeader = ({ isLoggedIn, sidebarOpen, setSidebarOpen, onLogout, toast }) => {
  return (
    <header className="glass-effect border-b border-white/20 px-6 py-4 flex items-center justify-between sticky top-0 z-50">
      <div className="flex items-center gap-4">
        {isLoggedIn && (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-white hover:bg-white/10"
          >
            {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        )}
        <div className="flex items-center gap-3">
          <Database className="h-8 w-8 text-blue-400" />
          <div>
            <h1 className="text-xl font-bold text-white">Plataforma de Leads</h1>
            <p className="text-sm text-gray-300">Banco Master - Crédito Consignado</p>
          </div>
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        {isLoggedIn && (
          <>
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white/10"
              onClick={() => toast({
                title: "🚧 Funcionalidade em desenvolvimento",
                description: "Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
              })}
            >
              <Bell className="h-5 w-5" />
            </Button>
            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-400 to-purple-500 flex items-center justify-center">
              <span className="text-white text-sm font-semibold">U</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/10"
              onClick={onLogout}
            >
              <LogOut className="h-5 w-5 mr-2" /> Sair
            </Button>
          </>
        )}
      </div>
    </header>
  );
};