import React from 'react';
import { motion } from 'framer-motion';
import { UserCog, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import UserStats from '@/components/admin/UserStats';
import UserForm from '@/components/admin/UserForm';
import UserTable from '@/components/admin/UserTable';
import { usuarios as mockUsers } from '@/components/admin/mockData';

const AdministracaoUsuarios = () => {
  const { toast } = useToast();

  const handleAddUser = (userData) => {
    toast({
      title: "Usuário cadastrado!",
      description: `${userData.nome} foi cadastrado com sucesso.`
    });
  };

  return (
    <div className="space-y-6">
      <UserStats usuarios={mockUsers} />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass-effect rounded-xl p-6"
      >
        <div className="flex items-center gap-4 mb-6">
          <Plus className="h-5 w-5 text-green-400" />
          <h3 className="text-lg font-semibold text-white">Cadastrar Novo Usuário</h3>
        </div>
        <UserForm onSubmit={handleAddUser} />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass-effect rounded-xl p-6"
      >
        <div className="flex items-center gap-4 mb-6">
          <UserCog className="h-5 w-5 text-red-400" />
          <h3 className="text-lg font-semibold text-white">Usuários Cadastrados</h3>
        </div>
        <UserTable usuarios={mockUsers} />
      </motion.div>
    </div>
  );
};

export default AdministracaoUsuarios;