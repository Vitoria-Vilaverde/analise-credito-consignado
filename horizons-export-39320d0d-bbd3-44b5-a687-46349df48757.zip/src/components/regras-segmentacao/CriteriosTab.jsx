import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Plus, Edit, CheckCircle, Clock, Download, Upload } from 'lucide-react';

const CriterioCard = ({ criterio, index }) => {
  const { toast } = useToast();

  const showToastNotImplemented = () => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: "Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
    });
  };

  return (
    <motion.div
      key={criterio.id}
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.1 }}
      className="bg-white/5 rounded-lg p-4 border border-white/10"
    >
      <div className="flex items-center justify-between mb-3">
        <h5 className="font-medium text-white">{criterio.nome}</h5>
        <div className="flex items-center gap-2">
          {criterio.ativo ? (
            <CheckCircle className="h-4 w-4 text-green-500" />
          ) : (
            <Clock className="h-4 w-4 text-gray-500" />
          )}
          <Button
            size="sm"
            variant="outline"
            className="border-white/20 text-white hover:bg-white/10"
            onClick={showToastNotImplemented}
          >
            <Edit className="h-3 w-3" />
          </Button>
        </div>
      </div>
      <p className="text-sm text-gray-400 mb-3">{criterio.descricao}</p>
      <div className="flex flex-wrap gap-1">
        {criterio.opcoes.map((opcao, idx) => (
          <span
            key={idx}
            className="px-2 py-1 bg-indigo-500/20 text-indigo-300 text-xs rounded-full"
          >
            {opcao}
          </span>
        ))}
      </div>
    </motion.div>
  );
};

const CriteriosTab = ({ criterios }) => {
  const { toast } = useToast();

  const showToastNotImplemented = () => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: "Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap justify-between items-center gap-2">
        <h4 className="text-md font-medium text-white">Critérios Disponíveis</h4>
        <div className="flex gap-2">
          <Button
            className="bg-teal-600 hover:bg-teal-700"
            onClick={showToastNotImplemented}
            size="sm"
          >
            <Upload className="h-4 w-4 mr-2" />
            Importar Critérios
          </Button>
          <Button
            variant="outline"
            className="border-white/20 text-white hover:bg-white/10"
            onClick={showToastNotImplemented}
            size="sm"
          >
            <Download className="h-4 w-4 mr-2" />
            Exportar Critérios
          </Button>
          <Button
            className="bg-green-600 hover:bg-green-700"
            onClick={showToastNotImplemented}
            size="sm"
          >
            <Plus className="h-4 w-4 mr-2" />
            Novo Critério
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {criterios.map((criterio, index) => (
          <CriterioCard key={criterio.id} criterio={criterio} index={index} />
        ))}
      </div>
    </div>
  );
};

export default CriteriosTab;