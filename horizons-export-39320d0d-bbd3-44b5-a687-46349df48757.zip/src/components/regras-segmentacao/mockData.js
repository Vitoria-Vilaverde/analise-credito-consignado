export const criterios = [
  {
    id: 1,
    nome: 'Convênio',
    descricao: 'Tipo de convênio do cliente',
    opcoes: ['INSS', 'SIAPE', 'Estadual', 'Municipal', 'Privado'],
    ativo: true
  },
  {
    id: 2,
    nome: 'Margem Consignável',
    descricao: 'Valor da margem disponível',
    opcoes: ['Sem margem', 'R$ 1-500', 'R$ 501-1000', 'R$ 1001+'],
    ativo: true
  },
  {
    id: 3,
    nome: 'Perfil do Cliente',
    descricao: 'Histórico de relacionamento',
    opcoes: ['Tomador Ativo', 'Tomador Inativo', 'Não Tomador', 'Novo Cliente'],
    ativo: true
  },
  {
    id: 4,
    nome: 'Qualidade do CPF',
    descricao: 'Status de validação do CPF',
    opcoes: ['Válido', 'Inválido', 'Pendente'],
    ativo: true
  },
  {
    id: 5,
    nome: 'Qualidade do Telefone',
    descricao: 'Status de validação do telefone',
    opcoes: ['Ativo', 'Inativo', 'Não informado'],
    ativo: true
  },
  {
    id: 6,
    nome: 'Score de Crédito',
    descricao: 'Pontuação de análise de crédito',
    opcoes: ['Alto (800+)', 'Médio (600-799)', 'Baixo (<600)', 'Não avaliado'],
    ativo: false
  }
];

export const regrasAutomaticas = [
  {
    id: 1,
    nome: 'Não Perturbe',
    descricao: 'Clientes que solicitaram para não receber ligações',
    condicao: 'Status = "Não Perturbe"',
    acao: 'Excluir da segmentação',
    ativo: true,
    aplicados: 1247
  },
  {
    id: 2,
    nome: 'Erro de Consulta',
    descricao: 'CPFs com erro na consulta de margem',
    condicao: 'Status Consulta = "Erro"',
    acao: 'Marcar para nova consulta',
    ativo: true,
    aplicados: 89
  },
  {
    id: 3,
    nome: 'Telefone Inválido',
    descricao: 'Telefones que retornaram erro na validação',
    condicao: 'Qualidade Telefone = "Inativo"',
    acao: 'Baixa prioridade',
    ativo: true,
    aplicados: 456
  },
  {
    id: 4,
    nome: 'Cliente VIP',
    descricao: 'Clientes com alto valor de contrato',
    condicao: 'Valor Contrato > R$ 50.000',
    acao: 'Alta prioridade',
    ativo: false,
    aplicados: 23
  }
];

export const regrasCombinadas = [
  {
    id: 1,
    nome: 'INSS Premium',
    descricao: 'INSS + Tomador Ativo + Margem > R$ 500',
    criterios: [
      { campo: 'Convênio', operador: '=', valor: 'INSS' },
      { campo: 'Perfil', operador: '=', valor: 'Tomador Ativo' },
      { campo: 'Margem', operador: '>', valor: 'R$ 500' }
    ],
    prioridade: 'Alta',
    leads: 5200,
    conversao: '28.5%',
    ativo: true
  },
  {
    id: 2,
    nome: 'SIAPE Qualificado',
    descricao: 'SIAPE + Idade 35-55 + Margem > R$ 800',
    criterios: [
      { campo: 'Convênio', operador: '=', valor: 'SIAPE' },
      { campo: 'Idade', operador: 'entre', valor: '35-55' },
      { campo: 'Margem', operador: '>', valor: 'R$ 800' }
    ],
    prioridade: 'Alta',
    leads: 2800,
    conversao: '22.1%',
    ativo: true
  },
  {
    id: 3,
    nome: 'Estadual Oportunidade',
    descricao: 'Estadual + Não Tomador + Telefone Ativo',
    criterios: [
      { campo: 'Convênio', operador: '=', valor: 'Estadual' },
      { campo: 'Perfil', operador: '=', valor: 'Não Tomador' },
      { campo: 'Telefone', operador: '=', valor: 'Ativo' }
    ],
    prioridade: 'Média',
    leads: 1200,
    conversao: '15.8%',
    ativo: true
  }
];