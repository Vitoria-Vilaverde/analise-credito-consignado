import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Plus, Edit, Trash2, CheckCircle, Clock, Download, Upload } from 'lucide-react';

const RegraAutomaticaRow = ({ regra, index }) => {
  const { toast } = useToast();

  const showToastNotImplemented = () => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: "Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
    });
  };

  return (
    <motion.tr
      key={regra.id}
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className="border-b border-white/10 table-row"
    >
      <td className="py-4 px-4">
        {regra.ativo ? (
          <CheckCircle className="h-4 w-4 text-green-500" />
        ) : (
          <Clock className="h-4 w-4 text-gray-500" />
        )}
      </td>
      <td className="py-4 px-4">
        <div>
          <p className="text-white font-medium">{regra.nome}</p>
          <p className="text-sm text-gray-400">{regra.descricao}</p>
        </div>
      </td>
      <td className="py-4 px-4 text-gray-300 font-mono text-sm">{regra.condicao}</td>
      <td className="py-4 px-4 text-blue-400">{regra.acao}</td>
      <td className="py-4 px-4 text-white font-semibold">{regra.aplicados.toLocaleString()}</td>
      <td className="py-4 px-4">
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            className="border-white/20 text-white hover:bg-white/10"
            onClick={showToastNotImplemented}
          >
            <Edit className="h-3 w-3" />
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="border-red-500/20 text-red-400 hover:bg-red-500/10"
            onClick={showToastNotImplemented}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      </td>
    </motion.tr>
  );
};

const RegrasAutomaticasTab = ({ regrasAutomaticas }) => {
  const { toast } = useToast();

  const showToastNotImplemented = () => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: "Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap justify-between items-center gap-2">
        <h4 className="text-md font-medium text-white">Regras Automáticas</h4>
        <div className="flex gap-2">
          <Button
            className="bg-teal-600 hover:bg-teal-700"
            onClick={showToastNotImplemented}
            size="sm"
          >
            <Upload className="h-4 w-4 mr-2" />
            Importar Regras
          </Button>
          <Button
            variant="outline"
            className="border-white/20 text-white hover:bg-white/10"
            onClick={showToastNotImplemented}
            size="sm"
          >
            <Download className="h-4 w-4 mr-2" />
            Exportar Regras
          </Button>
          <Button
            className="bg-green-600 hover:bg-green-700"
            onClick={showToastNotImplemented}
            size="sm"
          >
            <Plus className="h-4 w-4 mr-2" />
            Nova Regra
          </Button>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-white/20">
              <th className="text-left py-3 px-4 text-gray-300 font-medium">Status</th>
              <th className="text-left py-3 px-4 text-gray-300 font-medium">Nome</th>
              <th className="text-left py-3 px-4 text-gray-300 font-medium">Condição</th>
              <th className="text-left py-3 px-4 text-gray-300 font-medium">Ação</th>
              <th className="text-left py-3 px-4 text-gray-300 font-medium">Aplicados</th>
              <th className="text-left py-3 px-4 text-gray-300 font-medium">Ações</th>
            </tr>
          </thead>
          <tbody>
            {regrasAutomaticas.map((regra, index) => (
              <RegraAutomaticaRow key={regra.id} regra={regra} index={index} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default RegrasAutomaticasTab;