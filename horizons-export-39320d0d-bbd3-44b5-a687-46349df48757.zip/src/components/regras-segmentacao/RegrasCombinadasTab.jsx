import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Plus, Edit, Trash2, CheckCircle, Clock, Download, Upload } from 'lucide-react';

const getPrioridadeColor = (prioridade) => {
  switch (prioridade) {
    case 'Alta':
      return 'bg-green-500';
    case 'Média':
      return 'bg-yellow-500';
    case 'Baixa':
      return 'bg-red-500';
    default:
      return 'bg-gray-500';
  }
};

const RegraCombinadaCard = ({ regra, index }) => {
  const { toast } = useToast();

  const showToastNotImplemented = () => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: "Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
    });
  };

  return (
    <motion.div
      key={regra.id}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="bg-white/5 rounded-lg p-6 border border-white/10"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <h5 className="font-semibold text-white text-lg">{regra.nome}</h5>
          <span className={`px-3 py-1 rounded-full text-xs font-medium text-white ${getPrioridadeColor(regra.prioridade)}`}>
            {regra.prioridade}
          </span>
          {regra.ativo ? (
            <CheckCircle className="h-5 w-5 text-green-500" />
          ) : (
            <Clock className="h-5 w-5 text-gray-500" />
          )}
        </div>
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            className="border-white/20 text-white hover:bg-white/10"
            onClick={showToastNotImplemented}
          >
            <Edit className="h-3 w-3" />
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="border-red-500/20 text-red-400 hover:bg-red-500/10"
            onClick={showToastNotImplemented}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      </div>
      
      <p className="text-gray-400 mb-4">{regra.descricao}</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <h6 className="text-sm font-medium text-gray-300 mb-2">Critérios:</h6>
          <div className="space-y-1">
            {regra.criterios.map((criterio, idx) => (
              <div key={idx} className="text-sm text-gray-400">
                <span className="text-blue-400">{criterio.campo}</span>
                <span className="mx-2">{criterio.operador}</span>
                <span className="text-green-400">{criterio.valor}</span>
              </div>
            ))}
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-400">Leads Qualificados</p>
            <p className="text-xl font-bold text-white">{regra.leads.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-sm text-gray-400">Taxa de Conversão</p>
            <p className="text-xl font-bold text-green-400">{regra.conversao}</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const RegrasCombinadasTab = ({ regrasCombinadas }) => {
  const { toast } = useToast();

  const showToastNotImplemented = () => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: "Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap justify-between items-center gap-2">
        <h4 className="text-md font-medium text-white">Regras Combinadas</h4>
        <div className="flex gap-2">
          <Button
            className="bg-teal-600 hover:bg-teal-700"
            onClick={showToastNotImplemented}
            size="sm"
          >
            <Upload className="h-4 w-4 mr-2" />
            Importar Regras
          </Button>
          <Button
            variant="outline"
            className="border-white/20 text-white hover:bg-white/10"
            onClick={showToastNotImplemented}
            size="sm"
          >
            <Download className="h-4 w-4 mr-2" />
            Exportar Regras
          </Button>
          <Button
            className="bg-green-600 hover:bg-green-700"
            onClick={showToastNotImplemented}
            size="sm"
          >
            <Plus className="h-4 w-4 mr-2" />
            Nova Regra Combinada
          </Button>
        </div>
      </div>
      
      <div className="space-y-4">
        {regrasCombinadas.map((regra, index) => (
          <RegraCombinadaCard key={regra.id} regra={regra} index={index} />
        ))}
      </div>
    </div>
  );
};

export default RegrasCombinadasTab;