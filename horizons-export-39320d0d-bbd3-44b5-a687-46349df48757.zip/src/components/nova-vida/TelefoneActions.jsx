import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Phone, Search, Upload, RefreshCw, FileText } from 'lucide-react';

const TelefoneActions = ({
  cpfConsulta,
  setCpfConsulta,
  isLoading,
  onConsultarCPF,
  onImportarCSV,
  onAtualizarTelefones
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-effect rounded-xl p-6"
    >
      <div className="flex items-center gap-4 mb-6">
        <Phone className="h-5 w-5 text-pink-400" />
        <h3 className="text-lg font-semibold text-white">Nova Vida - Atualização de Telefones</h3>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="space-y-4">
          <h4 className="text-md font-medium text-white">Consulta Individual</h4>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">CPF</label>
              <input
                type="text"
                placeholder="000.000.000-00"
                className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-pink-500"
                value={cpfConsulta}
                onChange={(e) => setCpfConsulta(e.target.value)}
              />
            </div>
            <Button
              className="w-full bg-pink-600 hover:bg-pink-700"
              onClick={onConsultarCPF}
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Consultando...
                </>
              ) : (
                <>
                  <Search className="h-4 w-4 mr-2" />
                  Consultar CPF
                </>
              )}
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="text-md font-medium text-white">Importação em Lote</h4>
          <div className="space-y-3">
            <div className="border-2 border-dashed border-white/20 rounded-lg p-4 text-center">
              <FileText className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <p className="text-sm text-gray-400">Arraste um arquivo CSV ou clique para selecionar</p>
            </div>
            <Button
              className="w-full bg-green-600 hover:bg-green-700"
              onClick={onImportarCSV}
            >
              <Upload className="h-4 w-4 mr-2" />
              Importar CSV
            </Button>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="text-md font-medium text-white">Atualização Geral</h4>
          <div className="space-y-3">
            <div className="bg-white/5 rounded-lg p-4">
              <p className="text-sm text-gray-300 mb-2">Última atualização geral:</p>
              <p className="text-white font-medium">15/01/2024 às 14:30</p>
              <p className="text-xs text-gray-400 mt-1">1.247 telefones processados</p>
              <p className="text-xs text-green-400 mt-1">892 telefones atualizados</p>
            </div>
            <Button
              className="w-full bg-purple-600 hover:bg-purple-700"
              onClick={onAtualizarTelefones}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Atualizar Telefones
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default TelefoneActions;