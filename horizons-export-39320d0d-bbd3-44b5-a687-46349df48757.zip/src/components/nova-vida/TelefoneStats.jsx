import React from 'react';
import { motion } from 'framer-motion';
import { Phone, CheckCircle, AlertCircle, Clock, PhoneCall } from 'lucide-react';

const StatCard = ({ icon: Icon, value, label, color, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay }}
    className="kpi-card rounded-xl p-4"
  >
    <div className="flex items-center gap-3">
      <Icon className={`h-8 w-8 ${color}`} />
      <div>
        <p className="text-2xl font-bold text-gray-900">{value}</p>
        <p className="text-sm text-gray-600">{label}</p>
      </div>
    </div>
  </motion.div>
);

const TelefoneStats = ({ logAtualizacoes }) => {
  const stats = {
    total: logAtualizacoes.length,
    atualizados: logAtualizacoes.filter(l => l.status === 'atualizado').length,
    pendentes: logAtualizacoes.filter(l => l.status === 'pendente').length,
    erros: logAtualizacoes.filter(l => l.status === 'erro').length,
    ativos: logAtualizacoes.filter(l => l.qualidade === 'Ativo').length
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
      <StatCard icon={Phone} value={stats.total} label="Total Consultado" color="text-blue-600" delay={0} />
      <StatCard icon={CheckCircle} value={stats.atualizados} label="Atualizados" color="text-green-600" delay={0.1} />
      <StatCard icon={PhoneCall} value={stats.ativos} label="Telefones Ativos" color="text-purple-600" delay={0.2} />
      <StatCard icon={Clock} value={stats.pendentes} label="Pendentes" color="text-yellow-600" delay={0.3} />
      <StatCard icon={AlertCircle} value={stats.erros} label="Com Erro" color="text-red-600" delay={0.4} />
    </div>
  );
};

export default TelefoneStats;