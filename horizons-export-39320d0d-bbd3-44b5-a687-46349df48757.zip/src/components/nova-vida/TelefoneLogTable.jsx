import React from 'react';
import { motion } from 'framer-motion';
import { getStatusIcon, getStatusColor, getQualidadeColor } from '@/components/nova-vida/telefoneUtils.jsx';


const LogTableRow = ({ log, index }) => (
  <motion.tr
    key={log.id}
    initial={{ opacity: 0, x: -20 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ delay: index * 0.05 }}
    className="border-b border-white/10 table-row"
  >
    <td className="py-4 px-4">
      <div className="flex items-center gap-2">
        {getStatusIcon(log.status)}
        <span className={`px-2 py-1 rounded-full text-xs font-medium text-white ${getStatusColor(log.status)}`}>
          {log.status.charAt(0).toUpperCase() + log.status.slice(1)}
        </span>
      </div>
    </td>
    <td className="py-4 px-4 text-gray-300 font-mono">{log.cpf}</td>
    <td className="py-4 px-4 text-white font-medium">{log.nome}</td>
    <td className="py-4 px-4 text-gray-400">{log.telefoneAnterior}</td>
    <td className="py-4 px-4 text-blue-400 font-medium">{log.telefoneNovo}</td>
    <td className="py-4 px-4">
      <span className={`font-medium ${getQualidadeColor(log.qualidade)}`}>
        {log.qualidade}
      </span>
    </td>
    <td className="py-4 px-4 text-gray-300 text-sm">{log.dataAtualizacao}</td>
  </motion.tr>
);

const TelefoneLogTable = ({ logAtualizacoes }) => {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-white/20">
            <th className="text-left py-3 px-4 text-gray-300 font-medium">Status</th>
            <th className="text-left py-3 px-4 text-gray-300 font-medium">CPF</th>
            <th className="text-left py-3 px-4 text-gray-300 font-medium">Nome</th>
            <th className="text-left py-3 px-4 text-gray-300 font-medium">Telefone Anterior</th>
            <th className="text-left py-3 px-4 text-gray-300 font-medium">Telefone Novo</th>
            <th className="text-left py-3 px-4 text-gray-300 font-medium">Qualidade</th>
            <th className="text-left py-3 px-4 text-gray-300 font-medium">Data Atualização</th>
          </tr>
        </thead>
        <tbody>
          {logAtualizacoes.map((log, index) => (
            <LogTableRow key={log.id} log={log} index={index} />
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TelefoneLogTable;