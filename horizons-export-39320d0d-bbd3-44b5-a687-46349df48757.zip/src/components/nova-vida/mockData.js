export const logAtualizacoes = [
  {
    id: 1,
    cpf: '123.456.789-01',
    nome: 'João Silva Santos',
    telefoneAnterior: '(11) 99999-1234',
    telefoneNovo: '(11) 98888-5678',
    qualidade: 'Ativo',
    dataAtualizacao: '2024-01-15 14:30',
    status: 'atualizado'
  },
  {
    id: 2,
    cpf: '987.654.321-02',
    nome: 'Maria Oliveira Costa',
    telefoneAnterior: '(11) 88888-5678',
    telefoneNovo: '(11) 97777-9012',
    qualidade: 'Ativo',
    dataAtualizacao: '2024-01-15 13:45',
    status: 'atualizado'
  },
  {
    id: 3,
    cpf: '456.789.123-03',
    nome: 'Carlos Eduardo Lima',
    telefoneAnterior: '(11) 77777-9012',
    telefoneNovo: 'Não encontrado',
    qualidade: 'Inativo',
    dataAtualizacao: '2024-01-15 12:20',
    status: 'erro'
  },
  {
    id: 4,
    cpf: '789.123.456-04',
    nome: 'Ana Paula Ferreira',
    telefoneAnterior: '(11) 66666-3456',
    telefoneNovo: '(11) 95555-7890',
    qualidade: 'Ativo',
    dataAtualizacao: '2024-01-15 11:15',
    status: 'pendente'
  },
  {
    id: 5,
    cpf: '321.654.987-05',
    nome: 'Roberto Almeida Souza',
    telefoneAnterior: '(11) 55555-7890',
    telefoneNovo: '(11) 94444-1234',
    qualidade: 'Ativo',
    dataAtualizacao: '2024-01-15 10:30',
    status: 'atualizado'
  }
];