import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  CreditCard, 
  Search, 
  Upload, 
  RefreshCw,
  FileText,
  CheckCircle,
  AlertCircle,
  Clock,
  Download
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const AtualizacaoMargens = () => {
  const { toast } = useToast();
  const [cpfConsulta, setCpfConsulta] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const margensRecentes = [
    {
      id: 1,
      cpf: '123.456.789-01',
      nome: 'João Silva Santos',
      convenio: 'INSS',
      margemAtual: 'R$ 850,00',
      limiteTotal: 'R$ 45.000,00',
      limiteParcela: 'R$ 850,00',
      ultimaAtualizacao: '2024-01-15 14:30',
      status: 'atualizada'
    },
    {
      id: 2,
      cpf: '987.654.321-02',
      nome: 'Maria Oliveira Costa',
      convenio: 'SIAPE',
      margemAtual: 'R$ 1.200,00',
      limiteTotal: 'R$ 65.000,00',
      limiteParcela: 'R$ 1.200,00',
      ultimaAtualizacao: '2024-01-15 13:45',
      status: 'atualizada'
    },
    {
      id: 3,
      cpf: '456.789.123-03',
      nome: 'Carlos Eduardo Lima',
      convenio: 'Estadual',
      margemAtual: 'R$ 450,00',
      limiteTotal: 'R$ 25.000,00',
      limiteParcela: 'R$ 450,00',
      ultimaAtualizacao: '2024-01-15 12:20',
      status: 'erro'
    },
    {
      id: 4,
      cpf: '789.123.456-04',
      nome: 'Ana Paula Ferreira',
      convenio: 'INSS',
      margemAtual: 'R$ 950,00',
      limiteTotal: 'R$ 52.000,00',
      limiteParcela: 'R$ 950,00',
      ultimaAtualizacao: '2024-01-15 11:15',
      status: 'pendente'
    },
    {
      id: 5,
      cpf: '321.654.987-05',
      nome: 'Roberto Almeida Souza',
      convenio: 'SIAPE',
      margemAtual: 'R$ 680,00',
      limiteTotal: 'R$ 38.000,00',
      limiteParcela: 'R$ 680,00',
      ultimaAtualizacao: '2024-01-15 10:30',
      status: 'atualizada'
    }
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case 'atualizada':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'pendente':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'erro':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'atualizada':
        return 'bg-green-500';
      case 'pendente':
        return 'bg-yellow-500';
      case 'erro':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const showToastNotImplemented = () => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: "Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
    });
  };

  const handleConsultarCPF = async () => {
    if (!cpfConsulta) {
      toast({
        title: "CPF obrigatório",
        description: "Por favor, informe um CPF para consulta.",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Consulta realizada!",
        description: `Margem atualizada para CPF ${cpfConsulta}. Nova margem: R$ 1.250,00`
      });
      setCpfConsulta('');
    }, 2000);
  };

  const stats = {
    total: margensRecentes.length,
    atualizadas: margensRecentes.filter(m => m.status === 'atualizada').length,
    pendentes: margensRecentes.filter(m => m.status === 'pendente').length,
    erros: margensRecentes.filter(m => m.status === 'erro').length
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="kpi-card rounded-xl p-4"
        >
          <div className="flex items-center gap-3">
            <CreditCard className="h-8 w-8 text-blue-600" />
            <div>
              <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              <p className="text-sm text-gray-600">Total Consultado</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="kpi-card rounded-xl p-4"
        >
          <div className="flex items-center gap-3">
            <CheckCircle className="h-8 w-8 text-green-600" />
            <div>
              <p className="text-2xl font-bold text-gray-900">{stats.atualizadas}</p>
              <p className="text-sm text-gray-600">Atualizadas</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="kpi-card rounded-xl p-4"
        >
          <div className="flex items-center gap-3">
            <Clock className="h-8 w-8 text-yellow-600" />
            <div>
              <p className="text-2xl font-bold text-gray-900">{stats.pendentes}</p>
              <p className="text-sm text-gray-600">Pendentes</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="kpi-card rounded-xl p-4"
        >
          <div className="flex items-center gap-3">
            <AlertCircle className="h-8 w-8 text-red-600" />
            <div>
              <p className="text-2xl font-bold text-gray-900">{stats.erros}</p>
              <p className="text-sm text-gray-600">Com Erro</p>
            </div>
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-effect rounded-xl p-6"
      >
        <div className="flex items-center gap-4 mb-6">
          <CreditCard className="h-5 w-5 text-blue-400" />
          <h3 className="text-lg font-semibold text-white">Atualização de Margens</h3>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="space-y-4">
            <h4 className="text-md font-medium text-white">Consulta Individual</h4>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">CPF</label>
                <input
                  type="text"
                  placeholder="000.000.000-00"
                  className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  value={cpfConsulta}
                  onChange={(e) => setCpfConsulta(e.target.value)}
                />
              </div>
              <Button
                className="w-full bg-blue-600 hover:bg-blue-700"
                onClick={handleConsultarCPF}
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Consultando...
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4 mr-2" />
                    Consultar CPF
                  </>
                )}
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-md font-medium text-white">Importação em Lote</h4>
            <div className="space-y-3">
              <div className="border-2 border-dashed border-white/20 rounded-lg p-4 text-center">
                <FileText className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-400">Arraste um arquivo CSV ou clique para selecionar</p>
              </div>
              <Button
                className="w-full bg-green-600 hover:bg-green-700"
                onClick={showToastNotImplemented}
              >
                <Upload className="h-4 w-4 mr-2" />
                Importar CSV
              </Button>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-md font-medium text-white">Atualização Geral</h4>
            <div className="space-y-3">
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-300 mb-2">Última atualização geral:</p>
                <p className="text-white font-medium">15/01/2024 às 14:30</p>
                <p className="text-xs text-gray-400 mt-1">2.847 registros processados</p>
              </div>
              <Button
                className="w-full bg-purple-600 hover:bg-purple-700"
                onClick={showToastNotImplemented}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Atualizar Todos
              </Button>
            </div>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass-effect rounded-xl p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <CreditCard className="h-5 w-5 text-blue-400" />
            <h3 className="text-lg font-semibold text-white">Margens Atualizadas Recentemente</h3>
          </div>
          <Button
            variant="outline"
            className="border-white/20 text-white hover:bg-white/10"
            onClick={showToastNotImplemented}
          >
            <Download className="h-4 w-4 mr-2" />
            Exportar Dados
          </Button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/20">
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Status</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">CPF</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Nome</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Convênio</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Margem</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Limite Total</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Limite Parcela</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Última Atualização</th>
              </tr>
            </thead>
            <tbody>
              {margensRecentes.map((margem, index) => (
                <motion.tr
                  key={margem.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-white/10 table-row"
                >
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(margem.status)}
                      <span className={`px-2 py-1 rounded-full text-xs font-medium text-white ${getStatusColor(margem.status)}`}>
                        {margem.status.charAt(0).toUpperCase() + margem.status.slice(1)}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-4 text-gray-300 font-mono">{margem.cpf}</td>
                  <td className="py-4 px-4 text-white font-medium">{margem.nome}</td>
                  <td className="py-4 px-4 text-gray-300">{margem.convenio}</td>
                  <td className="py-4 px-4 text-green-400 font-semibold">{margem.margemAtual}</td>
                  <td className="py-4 px-4 text-blue-400 font-semibold">{margem.limiteTotal}</td>
                  <td className="py-4 px-4 text-purple-400 font-semibold">{margem.limiteParcela}</td>
                  <td className="py-4 px-4 text-gray-300 text-sm">{margem.ultimaAtualizacao}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
};

export default AtualizacaoMargens;