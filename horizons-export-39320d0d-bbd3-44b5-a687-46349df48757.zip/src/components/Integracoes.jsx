import React from 'react';
import { motion } from 'framer-motion';
import IntegrationCardWrapper from '@/components/integracoes/IntegrationCardWrapper';
import { getIntegrationsConfig } from '@/components/integracoes/integrationsConfig';

const Integracoes = (props) => {
  const integracoesDisponiveis = getIntegrationsConfig(props);

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <h2 className="text-3xl font-bold text-white mb-2">Gerenciar Integrações</h2>
        <p className="text-gray-300 max-w-2xl mx-auto">
          Conecte a plataforma com suas ferramentas e fontes de dados essenciais para otimizar seu fluxo de trabalho e análise de leads.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {integracoesDisponiveis.map((integracao) => (
          <IntegrationCardWrapper
            key={integracao.id}
            config={integracao}
            {...props} 
          />
        ))}
      </div>
    </div>
  );
};

export default Integracoes;