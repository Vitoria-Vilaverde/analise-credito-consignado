import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { getActivityLogs } from '@/services/supabaseService';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from './ui/button';
import { RefreshCw } from 'lucide-react';

const ActivityLog = () => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchLogs = async () => {
    setLoading(true);
    const { data, error } = await getActivityLogs();
    if (error) {
      console.error("Erro ao buscar logs:", error);
    } else {
      setLogs(data);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const getStatusVariant = (status) => {
    switch (status.toUpperCase()) {
      case 'SUCCESS':
        return 'success';
      case 'FAILURE':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-slate-800/50 border border-slate-700 rounded-xl p-6 shadow-lg"
    >
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-white">Logs de Atividade da Plataforma</h3>
        <Button onClick={fetchLogs} disabled={loading} size="sm" variant="outline">
          <RefreshCw className={`mr-2 h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          Atualizar
        </Button>
      </div>
      <div className="overflow-hidden rounded-lg border border-slate-700">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-slate-700/50 border-slate-700">
              <TableHead className="text-white">Data/Hora</TableHead>
              <TableHead className="text-white">Usuário</TableHead>
              <TableHead className="text-white">Ação</TableHead>
              <TableHead className="text-white">Status</TableHead>
              <TableHead className="text-white">Detalhes</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-slate-400 py-8">
                  Carregando logs...
                </TableCell>
              </TableRow>
            ) : logs.length > 0 ? (
              logs.map((log) => (
                <TableRow key={log.id} className="hover:bg-slate-800 border-slate-700">
                  <TableCell className="text-slate-300">
                    {new Date(log.created_at).toLocaleString('pt-BR')}
                  </TableCell>
                  <TableCell className="text-slate-300 font-medium">{log.user_email || 'N/A'}</TableCell>
                  <TableCell className="text-slate-300">{log.action_type}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusVariant(log.status)}>
                      {log.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-slate-400 text-xs">
                    <pre className="bg-slate-900/70 p-2 rounded-md overflow-x-auto">
                      {JSON.stringify(log.details, null, 2)}
                    </pre>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-slate-400 py-8">
                  Nenhum log de atividade encontrado.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </motion.div>
  );
};

export default ActivityLog;