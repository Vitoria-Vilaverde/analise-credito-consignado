import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { LogIn, Mail, Key, Eye, EyeOff, Database } from 'lucide-react';
import { initializeSupabaseClient } from '@/services/supabaseService';

const Login = ({ onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    const { supabase } = initializeSupabaseClient();
    if (!supabase) {
        toast({ title: "Erro de Configuração", description: "Cliente Supabase não inicializado.", variant: "destructive" });
        setIsLoading(false);
        return;
    }
    
    const { data, error } = await supabase.auth.signInWithPassword({
        email: email,
        password: password,
    });

    if (error) {
        toast({
          title: 'Erro de login',
          description: error.message || 'E-mail ou senha inválidos. Tente novamente.',
          variant: 'destructive',
        });
    } else if (data.user) {
        toast({
          title: 'Login bem-sucedido!',
          description: 'Bem-vindo de volta!',
        });
        if (onLoginSuccess) {
            onLoginSuccess();
        }
    }
    setIsLoading(false);
  };

  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-120px)]">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="glass-effect p-8 md:p-12 rounded-xl shadow-2xl w-full max-w-md"
      >
        <div className="flex flex-col items-center mb-8">
          <Database className="h-16 w-16 text-blue-400 mb-4" />
          <h1 className="text-3xl font-bold text-white text-center">Plataforma de Leads</h1>
          <p className="text-gray-300 text-center mt-1">Acesse sua conta para continuar</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
              <Mail className="h-4 w-4 mr-2 text-blue-400" /> E-mail
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              placeholder="seuemail@exemplo.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
              <Key className="h-4 w-4 mr-2 text-blue-400" /> Senha
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 pr-12 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                placeholder="Sua senha"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white p-1"
              >
                {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center">
            </div>
            <a href="#" className="text-sm text-blue-400 hover:underline">
              Esqueceu a senha?
            </a>
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-3 rounded-lg shadow-lg transform hover:scale-105 transition-all duration-300"
            disabled={isLoading}
          >
            {isLoading ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2"
              ></motion.div>
            ) : (
              <LogIn className="h-5 w-5 mr-2" />
            )}
            {isLoading ? 'Entrando...' : 'Entrar'}
          </Button>
        </form>
        
        <p className="text-center text-gray-400 text-sm mt-8">
          Não tem uma conta?{' '}
          <a href="#" className="text-blue-400 hover:underline" onClick={() => toast({ title: "🚧 Solicite acesso ao administrador."})}>
            Solicite acesso
          </a>
        </p>
      </motion.div>
    </div>
  );
};

export default Login;