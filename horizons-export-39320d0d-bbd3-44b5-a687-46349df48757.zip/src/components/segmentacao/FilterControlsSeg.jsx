import React from 'react';
import { Target, Upload, Download, DollarSign, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { MegaphoneOff as SpeakerOff, AlertTriangle, Phone } from 'lucide-react';

const FilterControlsSeg = ({ filters, setFilters, handleApplySegmentation, handleFileUpload, handleExportData, fileInputRef, showToastNotImplemented }) => {
  const handleNumericFilterChange = (filterName, subKey, value) => {
    const numericValue = value === '' ? '' : parseFloat(value);
    setFilters(prev => ({
      ...prev,
      [filterName]: {
        ...prev[filterName],
        [subKey]: numericValue,
      }
    }));
  };

  return (
    <div className="glass-effect rounded-xl p-6">
      <div className="flex items-center gap-4 mb-6">
        <Target className="h-6 w-6 text-green-400" />
        <h3 className="text-xl font-semibold text-white">Filtros Avançados de Segmentação</h3>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-6">
        <div>
          <Label htmlFor="convenio-seg-filter" className="block text-sm font-medium text-gray-300 mb-1.5">Convênio</Label>
          <select 
            id="convenio-seg-filter"
            className="w-full px-3 py-2.5 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-green-500 transition-colors"
            value={filters.convenio}
            onChange={(e) => setFilters({...filters, convenio: e.target.value})}
          >
            <option value="todos">Todos</option>
            <option value="inss">INSS</option>
            <option value="siape">SIAPE</option>
            <option value="estadual">Estadual</option>
            <option value="municipal">Municipal</option>
          </select>
        </div>
        
        <div>
          <Label htmlFor="perfil-seg-filter" className="block text-sm font-medium text-gray-300 mb-1.5">Perfil do Cliente</Label>
          <select 
            id="perfil-seg-filter"
            className="w-full px-3 py-2.5 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-green-500 transition-colors"
            value={filters.perfilCliente}
            onChange={(e) => setFilters({...filters, perfilCliente: e.target.value})}
          >
            <option value="todos">Todos</option>
            <option value="tomador-ativo">Tomador Ativo</option>
            <option value="tomador-inativo">Tomador Inativo</option>
            <option value="nao-tomador">Não Tomador</option>
            <option value="novo-cliente">Novo Cliente</option>
          </select>
        </div>

        <div>
          <Label htmlFor="produto-seg-filter" className="block text-sm font-medium text-gray-300 mb-1.5">Produto</Label>
          <select 
            id="produto-seg-filter"
            className="w-full px-3 py-2.5 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-green-500 transition-colors"
            value={filters.produto}
            onChange={(e) => setFilters({...filters, produto: e.target.value})}
          >
            <option value="todos">Todos</option>
            <option value="cartão">Cartão</option>
            <option value="empréstimo">Empréstimo</option>
            <option value="saque">Saque</option>
          </select>
        </div>
        
        <div className="flex flex-col space-y-3">
          <Label className="block text-sm font-medium text-gray-300">Opções Adicionais</Label>
           <div className="flex items-center space-x-3">
            <Checkbox 
              id="nao-perturbe-seg" 
              checked={filters.naoPerturbe} 
              onCheckedChange={(checked) => setFilters({...filters, naoPerturbe: checked})} 
              className="border-gray-400 data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
            />
            <Label htmlFor="nao-perturbe-seg" className="text-sm text-gray-300 flex items-center gap-1.5 cursor-pointer"><SpeakerOff size={16}/> Não Perturbe</Label>
          </div>
          <div className="flex items-center space-x-3">
            <Checkbox 
              id="negativados-seg" 
              checked={filters.negativados} 
              onCheckedChange={(checked) => setFilters({...filters, negativados: checked})} 
              className="border-gray-400 data-[state=checked]:bg-red-500 data-[state=checked]:border-red-500" 
            />
            <Label htmlFor="negativados-seg" className="text-sm text-gray-300 flex items-center gap-1.5 cursor-pointer"><AlertTriangle size={16}/> Negativados</Label>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <div className="flex items-center mb-2">
            <Checkbox 
              id="filtro-margem-seg" 
              checked={filters.margem.ativo} 
              onCheckedChange={(checked) => setFilters(prev => ({...prev, margem: {...prev.margem, ativo: checked}}))}
              className="border-gray-400 data-[state=checked]:bg-green-500 data-[state=checked]:border-green-500"
            />
            <Label htmlFor="filtro-margem-seg" className="ml-2 text-sm font-medium text-gray-300 flex items-center gap-1.5 cursor-pointer"><DollarSign size={16}/> Filtrar por Margem (Limite Disponível)</Label>
          </div>
          {filters.margem.ativo && (
            <div className="grid grid-cols-2 gap-3 pl-6">
              <div>
                <Label htmlFor="margem-min-seg" className="block text-xs text-gray-400 mb-1">Mínimo</Label>
                <Input 
                  type="number" 
                  id="margem-min-seg" 
                  placeholder="Ex: 100"
                  value={filters.margem.min === null ? '' : filters.margem.min}
                  onChange={(e) => handleNumericFilterChange('margem', 'min', e.target.value)}
                  className="w-full bg-white/10 border-white/20"
                />
              </div>
              <div>
                <Label htmlFor="margem-max-seg" className="block text-xs text-gray-400 mb-1">Máximo</Label>
                <Input 
                  type="number" 
                  id="margem-max-seg" 
                  placeholder="Ex: 1000"
                  value={filters.margem.max === null ? '' : filters.margem.max}
                  onChange={(e) => handleNumericFilterChange('margem', 'max', e.target.value)}
                  className="w-full bg-white/10 border-white/20"
                />
              </div>
            </div>
          )}
        </div>

        <div>
          <div className="flex items-center mb-2">
            <Checkbox 
              id="filtro-saque-seg" 
              checked={filters.saque.ativo} 
              onCheckedChange={(checked) => setFilters(prev => ({...prev, saque: {...prev.saque, ativo: checked}}))}
              className="border-gray-400 data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500"
            />
            <Label htmlFor="filtro-saque-seg" className="ml-2 text-sm font-medium text-gray-300 flex items-center gap-1.5 cursor-pointer"><CreditCard size={16}/> Filtrar por Saque (Cesta)</Label>
          </div>
          {filters.saque.ativo && (
            <div className="grid grid-cols-2 gap-3 pl-6">
              <div>
                <Label htmlFor="saque-min-seg" className="block text-xs text-gray-400 mb-1">Mínimo</Label>
                <Input 
                  type="number" 
                  id="saque-min-seg" 
                  placeholder="Ex: 50"
                  value={filters.saque.min === null ? '' : filters.saque.min}
                  onChange={(e) => handleNumericFilterChange('saque', 'min', e.target.value)}
                  className="w-full bg-white/10 border-white/20"
                />
              </div>
              <div>
                <Label htmlFor="saque-max-seg" className="block text-xs text-gray-400 mb-1">Máximo</Label>
                <Input 
                  type="number" 
                  id="saque-max-seg" 
                  placeholder="Ex: 500"
                  value={filters.saque.max === null ? '' : filters.saque.max}
                  onChange={(e) => handleNumericFilterChange('saque', 'max', e.target.value)}
                  className="w-full bg-white/10 border-white/20"
                />
              </div>
            </div>
          )}
        </div>
      </div>
      
      <div className="flex flex-wrap gap-4 items-center">
        <Button 
          className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 text-white shadow-lg transition-all transform hover:scale-105"
          onClick={handleApplySegmentation}
        >
          <Target className="h-4 w-4 mr-2" />
          Aplicar Segmentação
        </Button>
        <Button 
          className="bg-blue-600 hover:bg-blue-700 text-white shadow-md transition-all transform hover:scale-105"
          onClick={showToastNotImplemented}
        >
          <Phone className="h-4 w-4 mr-2" />
          Iniciar Ligações
        </Button>
        <Button 
          variant="outline" 
          className="border-cyan-500/70 text-cyan-400 hover:bg-cyan-500/10 hover:text-cyan-300 transition-colors"
          onClick={() => fileInputRef.current && fileInputRef.current.click()}
        >
          <Upload className="h-4 w-4 mr-2" />
          Importar Segmentos (CSV)
        </Button>
        <input type="file" accept=".csv" ref={fileInputRef} onChange={handleFileUpload} className="hidden" />
        <Button 
          variant="outline" 
          className="border-pink-500/70 text-pink-400 hover:bg-pink-500/10 hover:text-pink-300 transition-colors"
          onClick={handleExportData}
        >
          <Download className="h-4 w-4 mr-2" />
          Exportar Segmentos (CSV)
        </Button>
      </div>
    </div>
  );
};

export default FilterControlsSeg;