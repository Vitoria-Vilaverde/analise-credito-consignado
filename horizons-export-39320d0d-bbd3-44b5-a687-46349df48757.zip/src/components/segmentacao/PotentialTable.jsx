import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const PotentialTable = ({ segments }) => {
  const { toast } = useToast();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2, duration: 0.4 }}
      className="glass-effect rounded-xl p-6"
    >
      <div className="flex items-center gap-4 mb-6">
        <TrendingUp className="h-6 w-6 text-green-400" />
        <h3 className="text-xl font-semibold text-white">Avaliação de Potencial dos Segmentos</h3>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full min-w-[700px]">
          <thead>
            <tr className="border-b border-white/20">
              <th className="text-left py-3.5 px-4 text-gray-300 font-semibold text-sm">Segmento</th>
              <th className="text-left py-3.5 px-4 text-gray-300 font-semibold text-sm">Leads</th>
              <th className="text-left py-3.5 px-4 text-gray-300 font-semibold text-sm">Conversão Estimada</th>
              <th className="text-left py-3.5 px-4 text-gray-300 font-semibold text-sm">ROI Projetado</th>
              <th className="text-left py-3.5 px-4 text-gray-300 font-semibold text-sm">Prioridade</th>
              <th className="text-left py-3.5 px-4 text-gray-300 font-semibold text-sm">Ações</th>
            </tr>
          </thead>
          <tbody>
            {segments.map((item, index) => (
              <motion.tr
                key={item.id || index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05, duration: 0.3 }}
                className="border-b border-white/10 table-row hover:bg-white/5 transition-colors"
              >
                <td className="py-4 px-4 text-white font-medium text-sm">{item.segmento_nome}</td>
                <td className="py-4 px-4 text-gray-300 text-sm">{item.leads_count.toLocaleString()}</td>
                <td className="py-4 px-4 text-gray-300 text-sm">{item.conversao_estimada}%</td>
                <td className="py-4 px-4 text-gray-300 text-sm">{item.roi_estimado}%</td>
                <td className="py-4 px-4">
                  <span className={`px-3 py-1.5 rounded-full text-xs font-semibold text-white ${item.cor} shadow-sm`}>
                    {item.prioridade}
                  </span>
                </td>
                <td className="py-4 px-4">
                  <Button
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-700 text-white shadow-md transition-all transform hover:scale-105"
                    onClick={() => toast({
                      title: `Segmento "${item.segmento_nome}" executado!`,
                      description: `${item.leads_count.toLocaleString()} leads estão prontos. Sucesso! 🚀`
                    })}
                  >
                    <Play className="h-4 w-4 mr-1.5" />
                    Executar
                  </Button>
                </td>
              </motion.tr>
            ))}
            {segments.length === 0 && (
              <tr>
                <td colSpan="6" className="text-center py-10 text-gray-400 text-lg">
                  Nenhum segmento encontrado. Ajuste os filtros ou importe dados. 🎯
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
};

export default PotentialTable;