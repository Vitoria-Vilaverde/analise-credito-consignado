import React from 'react';
import { motion } from 'framer-motion';
import { BarChart3, PieChart } from 'lucide-react';
import { Bar, Doughnut } from 'react-chartjs-2';

const ChartsSeg = ({ convenioData, perfilDataChart, chartOptions, doughnutOptions, filteredDataPresent }) => {
  const chartContainerVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.4 } }
  };
  const chartContainerVariantsRight = {
    hidden: { opacity: 0, x: 20 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.4 } }
  };
  
  const NoDataMessage = () => (
    <p className="text-gray-400 text-center mt-10 text-lg">Sem dados para exibir com os filtros atuais. 📊</p>
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <motion.div
        variants={chartContainerVariants}
        initial="hidden"
        animate="visible"
        className="chart-container p-6 h-[450px]"
      >
        <div className="flex items-center gap-3 mb-4">
          <BarChart3 className="h-6 w-6 text-blue-400" />
          <h3 className="text-xl font-semibold text-white">Leads por Convênio (Segmentado)</h3>
        </div>
        {filteredDataPresent ? <Bar data={convenioData} options={chartOptions} /> : <NoDataMessage />}
      </motion.div>

      <motion.div
        variants={chartContainerVariantsRight}
        initial="hidden"
        animate="visible"
        className="chart-container p-6 h-[450px]"
      >
        <div className="flex items-center gap-3 mb-4">
          <PieChart className="h-6 w-6 text-purple-400" />
          <h3 className="text-xl font-semibold text-white">Leads por Perfil (Segmentado)</h3>
        </div>
        {filteredDataPresent ? <Doughnut data={perfilDataChart} options={doughnutOptions} /> : <NoDataMessage />}
      </motion.div>
    </div>
  );
};

export default ChartsSeg;