import React from 'react';
import { motion } from 'framer-motion';

const KpiCardsSeg = ({ kpis }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {kpis.map((kpi, index) => {
        const Icon = kpi.icon;
        return (
          <motion.div
            key={kpi.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05, duration: 0.3 }}
            className="kpi-card rounded-xl p-6 card-hover shadow-xl"
          >
            <div className="flex items-center justify-between mb-3">
              <div className={`p-3 rounded-lg ${kpi.bgColor} shadow-md`}>
                <Icon className="h-7 w-7 text-white" />
              </div>
            </div>
            <h3 className="text-3xl font-bold text-gray-100 mb-1.5 truncate" title={kpi.value}>{kpi.value}</h3>
            <p className="text-sm text-gray-400">{kpi.title}</p>
          </motion.div>
        );
      })}
    </div>
  );
};

export default KpiCardsSeg;