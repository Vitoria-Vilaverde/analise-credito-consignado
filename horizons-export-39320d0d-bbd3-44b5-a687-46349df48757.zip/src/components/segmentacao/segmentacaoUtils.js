export const initialSegmentData = [
  { id: 1, segmento_nome: 'INSS + Tomador Ativo', leads_count: 5200, conversao_estimada: 28.5, roi_estimado: 320, prioridade: 'Alta', cor: 'bg-green-600', produto: 'Empréstimo', nao_perturbe: false, negativado: false, limite_disponivel: 700, saque_cred_cesta: 150, convenio: 'INSS', perfil_cliente: 'Tomador Ativo' },
  { id: 2, segmento_nome: 'SIAPE + Margem > R$500', leads_count: 2800, conversao_estimada: 22.1, roi_estimado: 280, prioridade: 'Alta', cor: 'bg-green-600', produto: 'Cartão', nao_perturbe: false, negativado: false, limite_disponivel: 600, saque_cred_cesta: 50, convenio: 'SIAPE', perfil_cliente: 'Tomador Ativo' },
  { id: 3, segmento_nome: 'Estadual + Não Tomador', leads_count: 1200, conversao_estimada: 15.8, roi_estimado: 180, prioridade: 'Média', cor: 'bg-yellow-500', produto: 'Saque', nao_perturbe: true, negativado: false, limite_disponivel: 100, saque_cred_cesta: 200, convenio: 'Estadual', perfil_cliente: 'Não Tomador' },
  { id: 4, segmento_nome: 'Municipal + Novo Cliente', leads_count: 547, conversao_estimada: 8.2, roi_estimado: 95, prioridade: 'Baixa', cor: 'bg-red-600', produto: 'Empréstimo', nao_perturbe: false, negativado: true, limite_disponivel: -50, saque_cred_cesta: 0, convenio: 'Municipal', perfil_cliente: 'Novo Cliente' },
  { id: 5, segmento_nome: 'INSS + Negativados', leads_count: 800, conversao_estimada: 5.0, roi_estimado: 50, prioridade: 'Baixa', cor: 'bg-red-600', produto: 'Cartão', nao_perturbe: false, negativado: true, limite_disponivel: -100, saque_cred_cesta: -20, convenio: 'INSS', perfil_cliente: 'Tomador Inativo' },
];

export const processChartDataSeg = (data, key, label, countKey = 'leads_count') => {
  const counts = data.reduce((acc, item) => {
    const value = item[key] !== undefined && item[key] !== null ? item[key].toString() : 'Não Definido';
    acc[value] = (acc[value] || 0) + (item[countKey] || 0) ;
    return acc;
  }, {});
  return {
    labels: Object.keys(counts),
    datasets: [{
      label: label,
      data: Object.values(counts),
      backgroundColor: [
        'rgba(59, 130, 246, 0.85)', 'rgba(16, 185, 129, 0.85)', 'rgba(245, 158, 11, 0.85)', 
        'rgba(239, 68, 68, 0.85)', 'rgba(139, 92, 246, 0.85)', 'rgba(236, 72, 153, 0.85)',
        'rgba(14, 165, 233, 0.85)', 'rgba(244, 114, 182, 0.85)'
      ],
      borderColor: [
        'rgba(59, 130, 246, 1)', 'rgba(16, 185, 129, 1)', 'rgba(245, 158, 11, 1)', 
        'rgba(239, 68, 68, 1)', 'rgba(139, 92, 246, 1)', 'rgba(236, 72, 153, 1)',
        'rgba(14, 165, 233, 1)', 'rgba(244, 114, 182, 1)'
      ],
      borderWidth: 1.5,
      borderRadius: 5,
      hoverBorderWidth: 2.5,
      hoverBorderColor: '#fff'
    }]
  };
};

export const chartOptionsSeg = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'bottom',
      labels: { 
        color: '#CBD5E1', 
        font: { size: 13, family: "'Inter', sans-serif" },
        padding: 20,
        usePointStyle: true,
        pointStyle: 'rectRounded'
      } 
    },
    tooltip: {
      enabled: true,
      backgroundColor: 'rgba(0,0,0,0.8)',
      titleFont: { size: 14, family: "'Inter', sans-serif", weight: 'bold' },
      bodyFont: { size: 12, family: "'Inter', sans-serif" },
      padding: 10,
      cornerRadius: 6,
      displayColors: true,
      borderColor: 'rgba(255,255,255,0.2)',
      borderWidth: 1
    }
  },
  scales: {
    y: {
      beginAtZero: true,
      ticks: { color: '#9CA3AF', font: { family: "'Inter', sans-serif" } },
      grid: { color: 'rgba(255,255,255,0.08)'}
    },
    x: {
      ticks: { color: '#9CA3AF', font: { family: "'Inter', sans-serif" } },
      grid: { color: 'rgba(255,255,255,0.08)'}
    }
  },
  animation: {
    duration: 600,
    easing: 'easeInOutQuart'
  }
};

export const doughnutOptionsSeg = {
  ...chartOptionsSeg,
  plugins: {
    ...chartOptionsSeg.plugins,
    legend: {
      position: 'right',
      labels: { 
        color: '#CBD5E1',
        font: { size: 13, family: "'Inter', sans-serif" },
        padding: 15,
        usePointStyle: true,
        pointStyle: 'circle'
      }
    },
  },
};