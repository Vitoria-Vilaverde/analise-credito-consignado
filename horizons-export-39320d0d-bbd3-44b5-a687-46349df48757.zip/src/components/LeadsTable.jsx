import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { listarLeads, limparLeads } from '@/services/leadsService';
import { RefreshCw, Trash2, Search, ChevronLeft, ChevronRight } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const LeadsTable = ({ onLeadsLoaded }) => {
  const [leads, setLeads] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);
  const { toast } = useToast();

  const carregarLeadsDoDB = useCallback(async () => {
    setIsLoading(true);
    try {
      const dados = await listarLeads();
      setLeads(dados);
      if (typeof onLeadsLoaded === 'function') {
        onLeadsLoaded(dados);
      }
      toast({ title: "Leads Carregados", description: `${dados.length} leads carregados do banco de dados local.` });
    } catch (error) {
      toast({ title: "Erro ao Carregar Leads", description: "Não foi possível carregar os leads do banco local.", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  }, [onLeadsLoaded, toast]);

  useEffect(() => {
    carregarLeadsDoDB();
  }, [carregarLeadsDoDB]);

  const limparBanco = async () => {
    setIsLoading(true);
    await limparLeads();
    await carregarLeadsDoDB(); 
  };

  const filteredLeads = useMemo(() => {
    if (!searchTerm) return leads;
    return leads.filter(lead =>
      Object.values(lead).some(value =>
        String(value).toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  }, [leads, searchTerm]);

  const paginatedLeads = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredLeads.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredLeads, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredLeads.length / itemsPerPage);

  const handleNextPage = () => {
    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
  };

  const handlePrevPage = () => {
    if (currentPage > 1) setCurrentPage(currentPage - 1);
  };
  
  const tableHeaders = [
    "CPF", "Nome", "Telefone", "Convênio", "Margem", "Produto", "Banco", "Perfil", "Estado", "Origem Planilha"
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 sm:p-6 bg-slate-800 rounded-lg shadow-xl text-white"
    >
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <h1 className="text-2xl sm:text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">
          Leads no Banco de Dados Local
        </h1>
        <div className="flex gap-2">
          <Button onClick={carregarLeadsDoDB} variant="outline" className="text-sky-400 border-sky-500/50 hover:bg-sky-500/10">
            <RefreshCw className="h-4 w-4 mr-2" /> Recarregar
          </Button>
          <Button onClick={limparBanco} variant="destructive" className="bg-red-600 hover:bg-red-700">
            <Trash2 className="h-4 w-4 mr-2" /> Limpar Banco
          </Button>
        </div>
      </div>

      <div className="mb-4 flex items-center gap-2 bg-slate-700 p-3 rounded-md">
        <Search className="text-slate-400" />
        <Input
          type="text"
          placeholder="Buscar em todos os campos..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="bg-transparent border-none text-white placeholder-slate-400 focus:ring-0"
        />
      </div>
      
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <motion.div 
            animate={{ rotate: 360 }} 
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            className="w-12 h-12 border-t-4 border-b-4 border-purple-500 rounded-full"
          />
        </div>
      ) : paginatedLeads.length === 0 ? (
         <p className="text-center text-slate-400 py-10">Nenhum lead encontrado ou o banco de dados está vazio.</p>
      ) : (
        <>
          <div className="overflow-x-auto rounded-lg shadow-md bg-slate-750">
            <table className="w-full text-sm text-left text-slate-300">
              <thead className="text-xs text-slate-200 uppercase bg-slate-700">
                <tr>
                  {tableHeaders.map(header => (
                    <th key={header} scope="col" className="px-4 py-3 whitespace-nowrap">{header}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {paginatedLeads.map((lead) => (
                  <tr key={lead.id || lead.cpf} className="border-b border-slate-600 hover:bg-slate-650 transition-colors duration-150">
                    <td className="px-4 py-2 whitespace-nowrap">{lead.cpf}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{lead.nome}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{lead.telefone}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{lead.convenio}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{lead.margem}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{lead.produto}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{lead.banco}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{lead.perfil}</td>
                    <td className="px-4 py-2 whitespace-nowrap">{lead.estado}</td>
                    <td className="px-4 py-2 whitespace-nowrap max-w-xs truncate" title={lead.origem_planilha}>{lead.origem_planilha}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-6 flex flex-col sm:flex-row justify-between items-center text-sm text-slate-400">
            <div className="mb-2 sm:mb-0">
              Mostrando {paginatedLeads.length} de {filteredLeads.length} leads.
              Página {currentPage} de {totalPages}.
            </div>
            <div className="flex items-center gap-2">
              <select 
                value={itemsPerPage} 
                onChange={(e) => { setItemsPerPage(Number(e.target.value)); setCurrentPage(1); }}
                className="bg-slate-700 border border-slate-600 rounded-md px-2 py-1 text-white focus:ring-purple-500 focus:border-purple-500"
              >
                {[10, 25, 50, 100].map(size => (
                  <option key={size} value={size}>Mostrar {size}</option>
                ))}
              </select>
              <Button onClick={handlePrevPage} disabled={currentPage === 1} variant="outline" size="sm" className="text-slate-300 border-slate-600 hover:bg-slate-700">
                <ChevronLeft className="h-4 w-4" /> Anterior
              </Button>
              <Button onClick={handleNextPage} disabled={currentPage === totalPages} variant="outline" size="sm" className="text-slate-300 border-slate-600 hover:bg-slate-700">
                Próxima <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </>
      )}
    </motion.div>
  );
};

export default LeadsTable;