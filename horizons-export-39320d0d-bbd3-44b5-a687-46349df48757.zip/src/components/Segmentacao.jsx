import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { 
  Target, 
  TrendingUp, 
  Users, 
  DollarSign,
  UploadCloud,
  Download
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import FilterControlsSeg from '@/components/segmentacao/FilterControlsSeg';
import KpiCardsSeg from '@/components/segmentacao/KpiCardsSeg';
import ChartsSeg from '@/components/segmentacao/ChartsSeg';
import PotentialTable from '@/components/segmentacao/PotentialTable';
import { initialSegmentData, processChartDataSeg, chartOptionsSeg, doughnutOptionsSeg } from '@/components/segmentacao/segmentacaoUtils';
import { Button } from '@/components/ui/button';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

const Segmentacao = ({ globalLeadData }) => {
  const { toast } = useToast();
  const [segmentData, setSegmentData] = useState(initialSegmentData);
  const [filteredSegments, setFilteredSegments] = useState(initialSegmentData);
  const fileInputRef = useRef(null);

  const [filters, setFilters] = useState({
    convenio: 'todos',
    perfilCliente: 'todos',
    produto: 'todos',
    naoPerturbe: false,
    negativados: false,
    margem: {
      ativo: false,
      min: null,
      max: null,
    },
    saque: {
      ativo: false,
      min: null,
      max: null,
    }
  });

  const expectedSegmentHeaders = [
    "ID", "SEGMENTO_NOME", "LEADS_COUNT", "CONVERSAO_ESTIMADA", "ROI_ESTIMADO",
    "PRIORIDADE", "COR", "PRODUTO", "NAO_PERTURBE", "NEGATIVADO",
    "LIMITE_DISPONIVEL", "SAQUE_CRED_CESTA", "CONVENIO", "PERFIL_CLIENTE"
  ];

  useEffect(() => {
    if (globalLeadData && globalLeadData.length > 0) {
      toast({
        title: "Base de Leads Disponível para Segmentação",
        description: `${globalLeadData.length} leads da base global podem ser usados para criar novos segmentos. (Funcionalidade de criação de segmentos a partir da base global ainda não implementada).`
      });
    }
  }, [globalLeadData, toast]);


  const applyAllFiltersSeg = useCallback(() => {
    let data = [...segmentData];

    if (filters.convenio !== 'todos') {
      data = data.filter(seg => seg.convenio && seg.convenio.toLowerCase() === filters.convenio);
    }
    if (filters.perfilCliente !== 'todos') {
      data = data.filter(seg => seg.perfil_cliente && seg.perfil_cliente.toLowerCase().replace(/\s+/g, '-') === filters.perfilCliente);
    }
    if (filters.produto !== 'todos') {
      data = data.filter(seg => seg.produto && seg.produto.toLowerCase() === filters.produto);
    }
    if (filters.naoPerturbe) {
      data = data.filter(seg => seg.nao_perturbe === true || String(seg.nao_perturbe).toLowerCase() === 'true');
    }
    if (filters.negativados) {
      data = data.filter(seg => seg.negativado === true || String(seg.negativado).toLowerCase() === 'true' || parseFloat(seg.limite_disponivel) < 0 || parseFloat(seg.saque_cred_cesta) < 0 || parseFloat(seg.saque_creb_cesta) < 0);
    }

    if (filters.margem.ativo) {
      data = data.filter(seg => {
        const margemVal = parseFloat(seg.limite_disponivel);
        const minOk = filters.margem.min === null || filters.margem.min === '' || margemVal >= parseFloat(filters.margem.min);
        const maxOk = filters.margem.max === null || filters.margem.max === '' || margemVal <= parseFloat(filters.margem.max);
        return minOk && maxOk;
      });
    }

    if (filters.saque.ativo) {
      data = data.filter(seg => {
        const saqueVal = parseFloat(seg.saque_cred_cesta || seg.saque_creb_cesta);
        const minOk = filters.saque.min === null || filters.saque.min === '' || saqueVal >= parseFloat(filters.saque.min);
        const maxOk = filters.saque.max === null || filters.saque.max === '' || saqueVal <= parseFloat(filters.saque.max);
        return minOk && maxOk;
      });
    }

    setFilteredSegments(data);
  }, [filters, segmentData]);

  useEffect(() => {
    applyAllFiltersSeg();
  }, [filters, segmentData, applyAllFiltersSeg]);

  const handleApplySegmentation = () => {
    applyAllFiltersSeg();
    toast({
      title: "Filtros de Segmentação Aplicados!",
      description: "Os dados e gráficos de segmentação foram atualizados."
    });
  };

  const kpis = [
    { 
      title: 'Leads Segmentados', 
      value: filteredSegments.reduce((sum, seg) => sum + (parseFloat(seg.leads_count) || 0), 0).toLocaleString(), 
      icon: Users, 
      bgColor: 'bg-gradient-to-tr from-blue-500 to-blue-700'
    },
    { 
      title: '% com Margem (Estimado)', 
      value: `${(filteredSegments.filter(s => parseFloat(s.limite_disponivel) > 0).reduce((sum, seg) => sum + (parseFloat(seg.leads_count) || 0), 0) / (filteredSegments.reduce((sum, seg) => sum + (parseFloat(seg.leads_count) || 0), 0) || 1) * 100).toFixed(1)}%`,
      icon: DollarSign, 
      bgColor: 'bg-gradient-to-tr from-green-500 to-green-700'
    },
    { 
      title: '% Tomadores (Estimado)', 
      value: `${(filteredSegments.filter(s => s.perfil_cliente && s.perfil_cliente.toLowerCase().includes('tomador')).reduce((sum, seg) => sum + (parseFloat(seg.leads_count) || 0), 0) / (filteredSegments.reduce((sum, seg) => sum + (parseFloat(seg.leads_count) || 0), 0) || 1) * 100).toFixed(1)}%`,
      icon: Target, 
      bgColor: 'bg-gradient-to-tr from-purple-500 to-purple-700'
    },
    { 
      title: 'ROI Projetado Médio', 
      value: `${(filteredSegments.reduce((sum, seg) => sum + ((parseFloat(seg.roi_estimado) || 0) * (parseFloat(seg.leads_count) || 0)), 0) / (filteredSegments.reduce((sum, seg) => sum + (parseFloat(seg.leads_count) || 0), 0) || 1)).toFixed(0)}%`,
      icon: TrendingUp, 
      bgColor: 'bg-gradient-to-tr from-orange-500 to-orange-700'
    }
  ];

  const convenioData = processChartDataSeg(filteredSegments, 'convenio', 'Leads por Convênio');
  const perfilDataChart = processChartDataSeg(filteredSegments, 'perfil_cliente', 'Leads por Perfil do Cliente');

  const showToastNotImplemented = (featureName = "Esta funcionalidade") => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: `${featureName} ainda não foi implementada. Você pode solicitá-la no próximo prompt! 🚀`
    });
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target.result;
        try {
          const lines = text.split('\n').filter(line => line.trim() !== '');
          if (lines.length < 2) {
            toast({ title: "Erro no CSV", description: "Arquivo CSV precisa de cabeçalho e dados.", variant: "destructive" });
            return;
          }
          
          const headerFromFile = lines[0].split(',').map(h => h.trim().toUpperCase().replace(/\s+/g, '_'));
          
          const missingHeaders = expectedSegmentHeaders.filter(expectedHeader => !headerFromFile.includes(expectedHeader.toUpperCase()));

          if (missingHeaders.length > 0) {
             toast({ 
                title: "Erro de Cabeçalho no CSV de Segmentos", 
                description: `Cabeçalhos esperados não encontrados: ${missingHeaders.join(', ')}. Verifique o arquivo.`, 
                variant: "destructive", 
                duration: 9000 
            });
             return;
          }

          const data = lines.slice(1).map(line => {
            const values = line.split(',');
            let obj = {};
            headerFromFile.forEach((header, index) => {
              let value = values[index] ? values[index].trim() : '';
              const keyToStore = header.toLowerCase();

              if (['id', 'leads_count', 'conversao_estimada', 'roi_estimado', 'limite_disponivel', 'saque_cred_cesta', 'saque_creb_cesta'].includes(keyToStore)) {
                value = parseFloat(String(value).replace(',', '.')) || 0;
              } else if (keyToStore === 'nao_perturbe' || keyToStore === 'negativado') {
                value = value.toLowerCase() === 'true' || value === '1';
              }
              obj[keyToStore] = value;
            });
            obj.cor = obj.cor || 'bg-gray-500'; 
            obj.prioridade = obj.prioridade || 'Não definida';
            obj.perfil_cliente = obj.perfil_cliente || 'Não definido';
            obj.convenio = obj.convenio || 'Não definido';
            obj.produto = obj.produto || 'Não definido';
            return obj;
          });
          setSegmentData(data);
          toast({ title: "Importação Concluída!", description: `${data.length} segmentos importados.` });
        } catch (error) {
          toast({ title: "Erro ao Processar CSV", description: "Verifique o formato do arquivo.", variant: "destructive" });
          console.error("Erro ao processar CSV:", error);
        }
      };
      reader.onerror = () => {
        toast({ title: "Erro de Leitura", description: "Não foi possível ler o arquivo.", variant: "destructive" });
      };
      reader.readAsText(file);
    }
    if(fileInputRef.current) {
        fileInputRef.current.value = ""; 
    }
  };

  const handleExportData = () => {
    if (filteredSegments.length === 0) {
      toast({ title: "Nenhum Dado para Exportar", description: "Aplique filtros ou importe dados.", variant: "destructive" });
      return;
    }
    const headers = Object.keys(filteredSegments[0] || {}).map(header => header.replace(/_/g, ' ').toUpperCase()).join(',');
    const csvContent = [
      headers,
      ...filteredSegments.map(row => Object.values(row).map(val => typeof val === 'string' && val.includes(',') ? `"${val}"` : val).join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "segmentos_filtrados.csv");
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast({ title: "Exportação Iniciada!", description: "Seu arquivo CSV de segmentos está sendo baixado." });
    }
  };

  return (
    <motion.div 
      className="space-y-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="bg-slate-800/70 backdrop-blur-md shadow-2xl rounded-xl p-6">
        <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
            <h2 className="text-2xl font-bold text-white">Segmentação Avançada de Leads</h2>
            <div className="flex gap-3">
                <input
                    type="file"
                    accept=".csv"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    className="hidden"
                />
                <Button 
                    variant="outline" 
                    className="border-sky-500/70 text-sky-400 hover:bg-sky-500/10 hover:text-sky-300 transition-colors"
                    onClick={() => fileInputRef.current && fileInputRef.current.click()}
                >
                    <UploadCloud className="h-4 w-4 mr-2" /> Importar CSV de Segmentos
                </Button>
                <Button 
                    variant="outline" 
                    className="border-green-500/70 text-green-400 hover:bg-green-500/10 hover:text-green-300 transition-colors"
                    onClick={handleExportData}
                >
                    <Download className="h-4 w-4 mr-2" /> Exportar Segmentos Filtrados (CSV)
                </Button>
            </div>
        </div>
        <FilterControlsSeg
            filters={filters}
            setFilters={setFilters}
            handleApplySegmentation={handleApplySegmentation}
            showToastNotImplemented={showToastNotImplemented}
        />
      </div>
      <KpiCardsSeg kpis={kpis} />
      <ChartsSeg
        convenioData={convenioData}
        perfilDataChart={perfilDataChart}
        chartOptions={chartOptionsSeg}
        doughnutOptions={doughnutOptionsSeg}
        filteredDataPresent={filteredSegments.length > 0}
      />
      <PotentialTable segments={filteredSegments} />
    </motion.div>
  );
};

export default Segmentacao;