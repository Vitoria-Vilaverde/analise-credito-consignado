import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Settings, Filter, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import CriteriosTab from '@/components/regras-segmentacao/CriteriosTab';
import RegrasAutomaticasTab from '@/components/regras-segmentacao/RegrasAutomaticasTab';
import RegrasCombinadasTab from '@/components/regras-segmentacao/RegrasCombinadasTab';
import { criterios as mockCriterios } from '@/components/regras-segmentacao/mockData';
import { regrasAutomaticas as mockRegrasAutomaticas } from '@/components/regras-segmentacao/mockData';
import { regrasCombinadas as mockRegrasCombinadas } from '@/components/regras-segmentacao/mockData';

const RegrasSegmentacao = () => {
  const [activeTab, setActiveTab] = useState('criterios');

  const renderTabContent = () => {
    switch (activeTab) {
      case 'criterios':
        return <CriteriosTab criterios={mockCriterios} />;
      case 'automaticas':
        return <RegrasAutomaticasTab regrasAutomaticas={mockRegrasAutomaticas} />;
      case 'combinadas':
        return <RegrasCombinadasTab regrasCombinadas={mockRegrasCombinadas} />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-effect rounded-xl p-6"
      >
        <div className="flex items-center gap-4 mb-6">
          <Settings className="h-5 w-5 text-indigo-400" />
          <h3 className="text-lg font-semibold text-white">Regras de Segmentação</h3>
        </div>
        
        <div className="flex gap-2 mb-6">
          <Button
            variant={activeTab === 'criterios' ? 'default' : 'outline'}
            className={activeTab === 'criterios' ? 'bg-indigo-600 hover:bg-indigo-700' : 'border-white/20 text-white hover:bg-white/10'}
            onClick={() => setActiveTab('criterios')}
          >
            <Filter className="h-4 w-4 mr-2" />
            Critérios
          </Button>
          <Button
            variant={activeTab === 'automaticas' ? 'default' : 'outline'}
            className={activeTab === 'automaticas' ? 'bg-indigo-600 hover:bg-indigo-700' : 'border-white/20 text-white hover:bg-white/10'}
            onClick={() => setActiveTab('automaticas')}
          >
            <Settings className="h-4 w-4 mr-2" />
            Regras Automáticas
          </Button>
          <Button
            variant={activeTab === 'combinadas' ? 'default' : 'outline'}
            className={activeTab === 'combinadas' ? 'bg-indigo-600 hover:bg-indigo-700' : 'border-white/20 text-white hover:bg-white/10'}
            onClick={() => setActiveTab('combinadas')}
          >
            <Target className="h-4 w-4 mr-2" />
            Regras Combinadas
          </Button>
        </div>
        {renderTabContent()}
      </motion.div>
    </div>
  );
};

export default RegrasSegmentacao;