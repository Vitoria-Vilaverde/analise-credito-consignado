import React from 'react';
import { CheckCircle, AlertCircle, Clock } from 'lucide-react';

export const getNivelColor = (nivelAcesso) => {
  switch (nivelAcesso) {
    case 'administrador':
      return 'bg-red-500';
    case 'supervisor':
      return 'bg-yellow-500';
    case 'operador':
      return 'bg-blue-500';
    default:
      return 'bg-gray-500';
  }
};

export const getStatusIcon = (status) => {
  switch (status) {
    case 'ativo':
      return <CheckCircle className="h-4 w-4 text-green-400" />;
    case 'inativo':
      return <AlertCircle className="h-4 w-4 text-red-400" />;
    case 'pendente':
      return <Clock className="h-4 w-4 text-yellow-400" />;
    default:
      return <AlertCircle className="h-4 w-4 text-gray-400" />;
  }
};

export const getStatusColor = (status) => {
  switch (status) {
    case 'ativo':
      return 'bg-green-500/20 text-green-300';
    case 'inativo':
      return 'bg-red-500/20 text-red-300';
    case 'pendente':
      return 'bg-yellow-500/20 text-yellow-300';
    default:
      return 'bg-gray-500/20 text-gray-300';
  }
};