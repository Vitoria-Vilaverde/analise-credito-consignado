import React from 'react';
import { motion } from 'framer-motion';
import { User, CheckCircle, AlertCircle, Clock, Shield } from 'lucide-react';

const StatCard = ({ icon: Icon, value, label, color, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay }}
    className="kpi-card rounded-xl p-4"
  >
    <div className="flex items-center gap-3">
      <Icon className={`h-8 w-8 ${color}`} />
      <div>
        <p className="text-2xl font-bold text-gray-900">{value}</p>
        <p className="text-sm text-gray-600">{label}</p>
      </div>
    </div>
  </motion.div>
);

const UserStats = ({ usuarios }) => {
  const stats = {
    total: usuarios.length,
    ativos: usuarios.filter(u => u.status === 'ativo').length,
    inativos: usuarios.filter(u => u.status === 'inativo').length,
    pendentes: usuarios.filter(u => u.status === 'pendente').length,
    administradores: usuarios.filter(u => u.nivelAcesso === 'administrador').length
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
      <StatCard icon={User} value={stats.total} label="Total de Usuários" color="text-blue-600" delay={0} />
      <StatCard icon={CheckCircle} value={stats.ativos} label="Ativos" color="text-green-600" delay={0.1} />
      <StatCard icon={Clock} value={stats.pendentes} label="Pendentes" color="text-yellow-600" delay={0.2} />
      <StatCard icon={AlertCircle} value={stats.inativos} label="Inativos" color="text-red-600" delay={0.3} />
      <StatCard icon={Shield} value={stats.administradores} label="Administradores" color="text-purple-600" delay={0.4} />
    </div>
  );
};

export default UserStats;