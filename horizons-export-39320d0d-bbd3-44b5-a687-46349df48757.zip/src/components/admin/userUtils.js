import React from 'react';
import { CheckCircle, AlertCircle, Clock } from 'lucide-react';

export const getNivelColor = (nivel) => {
    switch (nivel) {
      case 'administrador':
        return 'bg-red-500';
      case 'supervisor':
        return 'bg-yellow-500';
      case 'operador':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };
  
export const getStatusIcon = (status) => {
  switch (status) {
    case 'ativo':
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    case 'inativo':
      return <AlertCircle className="h-4 w-4 text-red-500" />;
    case 'pendente':
      return <Clock className="h-4 w-4 text-yellow-500" />;
    default:
      return <AlertCircle className="h-4 w-4 text-gray-500" />;
  }
};

export const getStatusColor = (status) => {
  switch (status) {
    case 'ativo':
      return 'bg-green-500';
    case 'inativo':
      return 'bg-red-500';
    case 'pendente':
      return 'bg-yellow-500';
    default:
      return 'bg-gray-500';
  }
};