import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { User, Mail, Key, Shield, Eye, EyeOff, Plus } from 'lucide-react';

const UserForm = ({ onSubmit, initialData = { nome: '', email: '', senha: '', nivelAcesso: 'operador' } }) => {
  const [formData, setFormData] = useState(initialData);
  const [showPassword, setShowPassword] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
    setFormData(initialData); 
  };

  return (
    <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
            <User className="h-4 w-4 inline mr-2" /> Nome Completo *
          </label>
          <input
            type="text"
            name="nome"
            value={formData.nome}
            onChange={handleInputChange}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500"
            placeholder="Digite o nome completo"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
            <Mail className="h-4 w-4 inline mr-2" /> E-mail *
          </label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500"
            placeholder="usuario@empresa.com"
            required
          />
        </div>
      </div>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
            <Key className="h-4 w-4 inline mr-2" /> Senha *
          </label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              name="senha"
              value={formData.senha}
              onChange={handleInputChange}
              className="w-full px-3 py-2 pr-10 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500"
              placeholder="Digite a senha"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white"
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
            <Shield className="h-4 w-4 inline mr-2" /> Nível de Acesso
          </label>
          <select
            name="nivelAcesso"
            value={formData.nivelAcesso}
            onChange={handleInputChange}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-red-500"
          >
            <option value="operador">Operador</option>
            <option value="supervisor">Supervisor</option>
            <option value="administrador">Administrador</option>
          </select>
        </div>
      </div>
      <div className="md:col-span-2 flex gap-3">
        <Button type="submit" className="bg-green-600 hover:bg-green-700">
          <Plus className="h-4 w-4 mr-2" />
          Cadastrar Usuário
        </Button>
        <Button
          type="button"
          variant="outline"
          className="border-white/20 text-white hover:bg-white/10"
          onClick={() => setFormData(initialData)}
        >
          Limpar Formulário
        </Button>
      </div>
    </form>
  );
};

export default UserForm;