import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Edit, Trash2, CheckCircle, AlertCircle, Clock } from 'lucide-react';
import { getNivelColor, getStatusIcon, getStatusColor } from '@/components/admin/userUtils.jsx';

const UserTableRow = ({ usuario, index }) => {
  const { toast } = useToast();
  return (
    <motion.tr
      key={usuario.id}
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className="border-b border-white/10 table-row"
    >
      <td className="py-4 px-4">
        <div className="flex items-center gap-2">
          {getStatusIcon(usuario.status)}
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(usuario.status)}`}>
            {usuario.status.charAt(0).toUpperCase() + usuario.status.slice(1)}
          </span>
        </div>
      </td>
      <td className="py-4 px-4 text-white font-medium">{usuario.nome}</td>
      <td className="py-4 px-4 text-gray-300">{usuario.email}</td>
      <td className="py-4 px-4">
        <span className={`px-3 py-1 rounded-full text-xs font-medium text-white ${getNivelColor(usuario.nivelAcesso)}`}>
          {usuario.nivelAcesso.charAt(0).toUpperCase() + usuario.nivelAcesso.slice(1)}
        </span>
      </td>
      <td className="py-4 px-4 text-gray-300 text-sm">{usuario.ultimoLogin}</td>
      <td className="py-4 px-4 text-gray-300 text-sm">{new Date(usuario.dataCriacao).toLocaleDateString('pt-BR')}</td>
      <td className="py-4 px-4">
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            className="border-white/20 text-white hover:bg-white/10"
            onClick={() => toast({
              title: "🚧 Funcionalidade em desenvolvimento",
              description: "Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
            })}
          >
            <Edit className="h-3 w-3" />
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="border-red-500/20 text-red-400 hover:bg-red-500/10"
            onClick={() => toast({
              title: "🚧 Funcionalidade em desenvolvimento",
              description: "Esta funcionalidade ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀"
            })}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      </td>
    </motion.tr>
  );
};

const UserTable = ({ usuarios }) => {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-white/20">
            <th className="text-left py-3 px-4 text-gray-300 font-medium">Status</th>
            <th className="text-left py-3 px-4 text-gray-300 font-medium">Nome</th>
            <th className="text-left py-3 px-4 text-gray-300 font-medium">E-mail</th>
            <th className="text-left py-3 px-4 text-gray-300 font-medium">Nível de Acesso</th>
            <th className="text-left py-3 px-4 text-gray-300 font-medium">Último Login</th>
            <th className="text-left py-3 px-4 text-gray-300 font-medium">Data Criação</th>
            <th className="text-left py-3 px-4 text-gray-300 font-medium">Ações</th>
          </tr>
        </thead>
        <tbody>
          {usuarios.map((usuario, index) => (
            <UserTableRow key={usuario.id} usuario={usuario} index={index} />
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UserTable;