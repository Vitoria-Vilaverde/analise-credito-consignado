export const usuarios = [
  {
    id: 1,
    nome: 'João Silva',
    email: 'joao.silva@empresa.com',
    nivelAcesso: 'administrador',
    status: 'ativo',
    ultimoLogin: '2024-01-15 14:30',
    dataCriacao: '2023-06-15'
  },
  {
    id: 2,
    nome: 'Maria Santos',
    email: 'maria.santos@empresa.com',
    nivelAcesso: 'supervisor',
    status: 'ativo',
    ultimoLogin: '2024-01-15 13:45',
    dataCriacao: '2023-08-20'
  },
  {
    id: 3,
    nome: 'Carlos Oliveira',
    email: 'carlos.oliveira@empresa.com',
    nivelAcesso: 'operador',
    status: 'ativo',
    ultimoLogin: '2024-01-15 12:20',
    dataCriacao: '2023-09-10'
  },
  {
    id: 4,
    nome: 'Ana Costa',
    email: 'ana.costa@empresa.com',
    nivelAcesso: 'operador',
    status: 'inativo',
    ultimoLogin: '2024-01-10 16:15',
    dataCriacao: '2023-11-05'
  },
  {
    id: 5,
    nome: 'Roberto Lima',
    email: 'roberto.lima@empresa.com',
    nivelAcesso: 'supervisor',
    status: 'pendente',
    ultimoLogin: 'Nunca logou',
    dataCriacao: '2024-01-14'
  }
];