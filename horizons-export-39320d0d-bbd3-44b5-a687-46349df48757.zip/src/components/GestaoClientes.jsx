import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  Search, 
  Filter, 
  Calendar,
  DollarSign,
  Phone,
  Mail,
  Edit,
  Eye,
  AlertCircle,
  CheckCircle,
  Clock,
  Upload,
  Download
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const GestaoClientes = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('todos');

  const clientes = [
    {
      id: 1,
      cpf: '123.456.789-01',
      nome: 'João Silva Santos',
      ultimaVenda: '2024-01-15',
      valorContratado: 'R$ 15.000,00',
      margemLiberada: 'R$ 850,00',
      proximoContato: '2024-01-20',
      status: 'ativo',
      telefone: '(11) 99999-1234',
      email: 'joao.silva@email.com',
      convenio: 'INSS'
    },
    {
      id: 2,
      cpf: '987.654.321-02',
      nome: 'Maria Oliveira Costa',
      ultimaVenda: '2024-01-10',
      valorContratado: 'R$ 22.500,00',
      margemLiberada: 'R$ 1.200,00',
      proximoContato: '2024-01-18',
      status: 'pendente',
      telefone: '(11) 88888-5678',
      email: 'maria.oliveira@email.com',
      convenio: 'SIAPE'
    },
    {
      id: 3,
      cpf: '456.789.123-03',
      nome: 'Carlos Eduardo Lima',
      ultimaVenda: '2024-01-08',
      valorContratado: 'R$ 8.750,00',
      margemLiberada: 'R$ 450,00',
      proximoContato: '2024-01-25',
      status: 'ativo',
      telefone: '(11) 77777-9012',
      email: 'carlos.lima@email.com',
      convenio: 'Estadual'
    },
    {
      id: 4,
      cpf: '789.123.456-04',
      nome: 'Ana Paula Ferreira',
      ultimaVenda: '2024-01-05',
      valorContratado: 'R$ 18.900,00',
      margemLiberada: 'R$ 950,00',
      proximoContato: '2024-01-22',
      status: 'inativo',
      telefone: '(11) 66666-3456',
      email: 'ana.ferreira@email.com',
      convenio: 'INSS'
    },
    {
      id: 5,
      cpf: '321.654.987-05',
      nome: 'Roberto Almeida Souza',
      ultimaVenda: '2024-01-12',
      valorContratado: 'R$ 12.300,00',
      margemLiberada: 'R$ 680,00',
      proximoContato: '2024-01-19',
      status: 'ativo',
      telefone: '(11) 55555-7890',
      email: 'roberto.souza@email.com',
      convenio: 'SIAPE'
    }
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case 'ativo':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'pendente':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'inativo':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'ativo':
        return 'bg-green-500';
      case 'pendente':
        return 'bg-yellow-500';
      case 'inativo':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const filteredClientes = clientes.filter(cliente => {
    const matchesSearch = cliente.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         cliente.cpf.includes(searchTerm);
    const matchesStatus = statusFilter === 'todos' || cliente.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: clientes.length,
    ativos: clientes.filter(c => c.status === 'ativo').length,
    pendentes: clientes.filter(c => c.status === 'pendente').length,
    inativos: clientes.filter(c => c.status === 'inativo').length,
    valorTotal: clientes.reduce((acc, c) => acc + parseFloat(c.valorContratado.replace(/[R$.,\s]/g, '')), 0)
  };

  const showToastNotImplemented = (featureName = "Esta funcionalidade") => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: `${featureName} ainda não foi implementada—mas não se preocupe! Você pode solicitá-la no seu próximo prompt! 🚀`
    });
  };

  const handleViewClient = (clientName) => {
    toast({
      title: `Visualizando Cliente: ${clientName}`,
      description: "Detalhes do cliente serão exibidos aqui em breve. 📄"
    });
  };

  const handleEditClient = (clientName) => {
    toast({
      title: `Editando Cliente: ${clientName}`,
      description: "Formulário de edição do cliente será implementado aqui. ✏️"
    });
  };

  const handleCallClient = (clientName, clientPhone) => {
    toast({
      title: `Ligando para ${clientName}`,
      description: `Iniciando chamada para ${clientPhone}... 📞 (Simulação)`
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="kpi-card rounded-xl p-4"
        >
          <div className="flex items-center gap-3">
            <Users className="h-8 w-8 text-blue-600" />
            <div>
              <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              <p className="text-sm text-gray-600">Total de Clientes</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="kpi-card rounded-xl p-4"
        >
          <div className="flex items-center gap-3">
            <CheckCircle className="h-8 w-8 text-green-600" />
            <div>
              <p className="text-2xl font-bold text-gray-900">{stats.ativos}</p>
              <p className="text-sm text-gray-600">Ativos</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="kpi-card rounded-xl p-4"
        >
          <div className="flex items-center gap-3">
            <Clock className="h-8 w-8 text-yellow-600" />
            <div>
              <p className="text-2xl font-bold text-gray-900">{stats.pendentes}</p>
              <p className="text-sm text-gray-600">Pendentes</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="kpi-card rounded-xl p-4"
        >
          <div className="flex items-center gap-3">
            <AlertCircle className="h-8 w-8 text-red-600" />
            <div>
              <p className="text-2xl font-bold text-gray-900">{stats.inativos}</p>
              <p className="text-sm text-gray-600">Inativos</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="kpi-card rounded-xl p-4"
        >
          <div className="flex items-center gap-3">
            <DollarSign className="h-8 w-8 text-purple-600" />
            <div>
              <p className="text-lg font-bold text-gray-900">R$ {(stats.valorTotal / 1000).toFixed(0)}k</p>
              <p className="text-sm text-gray-600">Valor Total</p>
            </div>
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-effect rounded-xl p-6"
      >
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex flex-col md:flex-row gap-4 flex-1">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar por nome ou CPF..."
                className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-400" />
              <select
                className="px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="todos">Todos os Status</option>
                <option value="ativo">Ativos</option>
                <option value="pendente">Pendentes</option>
                <option value="inativo">Inativos</option>
              </select>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              className="bg-orange-600 hover:bg-orange-700"
              onClick={() => showToastNotImplemented("Importação de clientes")}
            >
              <Upload className="h-4 w-4 mr-2" />
              Importar Clientes
            </Button>
            <Button
              className="bg-blue-600 hover:bg-blue-700"
              onClick={() => showToastNotImplemented("Agendamento de contatos")}
            >
              <Calendar className="h-4 w-4 mr-2" />
              Agendar Contatos
            </Button>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass-effect rounded-xl p-6"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Users className="h-5 w-5 text-blue-400" />
            <h3 className="text-lg font-semibold text-white">Clientes com Vendas Realizadas</h3>
            <span className="text-sm text-gray-400">({filteredClientes.length} registros)</span>
          </div>
          <Button 
            variant="outline" 
            className="border-white/20 text-white hover:bg-white/10"
            onClick={() => showToastNotImplemented("Exportação de clientes")}
          >
            <Download className="h-4 w-4 mr-2" />
            Exportar Clientes
          </Button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/20">
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Status</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">CPF</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Nome</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Última Venda</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Valor Contratado</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Margem Liberada</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Próximo Contato</th>
                <th className="text-left py-3 px-4 text-gray-300 font-medium">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filteredClientes.map((cliente, index) => (
                <motion.tr
                  key={cliente.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-white/10 table-row"
                >
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(cliente.status)}
                      <span className={`px-2 py-1 rounded-full text-xs font-medium text-white ${getStatusColor(cliente.status)}`}>
                        {cliente.status.charAt(0).toUpperCase() + cliente.status.slice(1)}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-4 text-gray-300 font-mono">{cliente.cpf}</td>
                  <td className="py-4 px-4 text-white font-medium">{cliente.nome}</td>
                  <td className="py-4 px-4 text-gray-300">{new Date(cliente.ultimaVenda).toLocaleDateString('pt-BR')}</td>
                  <td className="py-4 px-4 text-green-400 font-semibold">{cliente.valorContratado}</td>
                  <td className="py-4 px-4 text-blue-400 font-semibold">{cliente.margemLiberada}</td>
                  <td className="py-4 px-4 text-gray-300">{new Date(cliente.proximoContato).toLocaleDateString('pt-BR')}</td>
                  <td className="py-4 px-4">
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-white/20 text-white hover:bg-white/10"
                        onClick={() => handleViewClient(cliente.nome)}
                      >
                        <Eye className="h-3 w-3" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-white/20 text-white hover:bg-white/10"
                        onClick={() => handleEditClient(cliente.nome)}
                      >
                        <Edit className="h-3 w-3" />
                      </Button>
                      <Button
                        size="sm"
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => handleCallClient(cliente.nome, cliente.telefone)}
                      >
                        <Phone className="h-3 w-3" />
                      </Button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {filteredClientes.length === 0 && (
          <div className="text-center py-8">
            <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-400">Nenhum cliente encontrado com os filtros aplicados.</p>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default GestaoClientes;