import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Users, DollarSign, Target, AlertTriangle, Download, UploadCloud } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement,
} from 'chart.js';
import FilterControls from '@/components/resumo-base/FilterControls';
import KpiCards from '@/components/resumo-base/KpiCards';
import Charts from '@/components/resumo-base/Charts';
import { processChartData, chartOptions, pieOptions, rendaDataExample } from '@/components/resumo-base/resumoBaseUtils';
import { Button } from '@/components/ui/button';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement
);

const ResumoBase = ({ globalLeadData, handleLeadUpload }) => {
  const { toast } = useToast();
  const [filteredData, setFilteredData] = useState(globalLeadData || []);
  const fileInputRef = useRef(null);

  const [filters, setFilters] = useState({
    banco: 'todos',
    convenio: 'todos',
    produto: 'todos',
    naoPerturbe: false,
    negativados: false,
    margem: {
      ativo: false,
      min: null,
      max: null,
    },
    saque: {
      ativo: false,
      min: null,
      max: null,
    }
  });
  
  useEffect(() => {
    setFilteredData(globalLeadData || []);
  }, [globalLeadData]);


  const applyAllFilters = useCallback(() => {
    let data = [...(globalLeadData || [])];

    if (filters.banco !== 'todos') {
      data = data.filter(lead => lead.banco && lead.banco.toLowerCase().replace(/\s+/g, '-') === filters.banco);
    }
    if (filters.convenio !== 'todos') {
      data = data.filter(lead => lead.convenio && lead.convenio.toLowerCase() === filters.convenio);
    }
    if (filters.produto !== 'todos') {
      data = data.filter(lead => lead.produto && lead.produto.toLowerCase() === filters.produto);
    }
    if (filters.naoPerturbe) {
      data = data.filter(lead => lead.nao_perturbe === true || String(lead.nao_perturbe).toLowerCase() === 'true');
    }
    if (filters.negativados) {
      data = data.filter(lead => parseFloat(lead.limite_disponivel) < 0 || parseFloat(lead.saque_cred_cesta) < 0 || parseFloat(lead.saque_creb_cesta) < 0);
    }

    if (filters.margem.ativo) {
      data = data.filter(lead => {
        const margemVal = parseFloat(lead.limite_disponivel);
        const minOk = filters.margem.min === null || filters.margem.min === '' || margemVal >= parseFloat(filters.margem.min);
        const maxOk = filters.margem.max === null || filters.margem.max === '' || margemVal <= parseFloat(filters.margem.max);
        return minOk && maxOk;
      });
    }

    if (filters.saque.ativo) {
      data = data.filter(lead => {
        const saqueVal = parseFloat(lead.saque_cred_cesta || lead.saque_creb_cesta);
        const minOk = filters.saque.min === null || filters.saque.min === '' || saqueVal >= parseFloat(filters.saque.min);
        const maxOk = filters.saque.max === null || filters.saque.max === '' || saqueVal <= parseFloat(filters.saque.max);
        return minOk && maxOk;
      });
    }
    
    setFilteredData(data);
  }, [filters, globalLeadData]);


  useEffect(() => {
    applyAllFilters();
  }, [filters, globalLeadData, applyAllFilters]);
  
  const handleApplyFilters = () => {
    applyAllFilters();
    toast({
      title: "Filtros Aplicados!",
      description: "Os dados e gráficos foram atualizados com sucesso."
    });
  };

  const kpis = [
    { 
      title: 'Total de Leads Filtrados', 
      value: filteredData.length.toLocaleString(), 
      icon: Users, 
      bgColor: 'bg-gradient-to-tr from-blue-500 to-blue-700'
    },
    { 
      title: '% com Margem', 
      value: `${(filteredData.filter(l => parseFloat(l.limite_disponivel) > 0).length / (filteredData.length || 1) * 100).toFixed(1)}%`, 
      icon: DollarSign, 
      bgColor: 'bg-gradient-to-tr from-green-500 to-green-700'
    },
    { 
      title: '% Tomadores', 
      value: `${(filteredData.filter(l => l.perfil && l.perfil.toLowerCase() === 'tomador').length / (filteredData.length || 1) * 100).toFixed(1)}%`, 
      icon: Target, 
      bgColor: 'bg-gradient-to-tr from-purple-500 to-purple-700'
    },
    { 
      title: 'Negativados', 
      value: filteredData.filter(l => parseFloat(l.limite_disponivel) < 0 || parseFloat(l.saque_cred_cesta) < 0 || parseFloat(l.saque_creb_cesta) < 0).length.toLocaleString(), 
      icon: AlertTriangle, 
      bgColor: 'bg-gradient-to-tr from-red-500 to-red-700'
    }
  ];

  const bancoData = processChartData(filteredData, 'banco', 'Leads por Banco');
  const estadoData = processChartData(filteredData, 'estado', 'Leads por Estado');
  const idadeData = processChartData(filteredData, 'idade', 'Distribuição por Idade');
  const rendaData = rendaDataExample; 

  const internalHandleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file && handleLeadUpload) {
      handleLeadUpload(file);
    }
    if(fileInputRef.current) {
        fileInputRef.current.value = ""; 
    }
  };

  const handleExportData = () => {
    if (filteredData.length === 0) {
      toast({ title: "Nenhum Dado para Exportar", description: "Aplique filtros ou importe dados primeiro.", variant: "destructive" });
      return;
    }
    const headers = Object.keys(filteredData[0] || {}).map(header => header.replace(/_/g, ' ').toUpperCase()).join(',');
    const csvContent = [
      headers,
      ...filteredData.map(row => Object.values(row).map(val => typeof val === 'string' && val.includes(',') ? `"${val}"` : val).join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", "leads_filtrados_resumo_base.csv");
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast({ title: "Exportação Iniciada!", description: "Seu arquivo CSV está sendo baixado." });
    }
  };
  
  return (
    <motion.div 
      className="space-y-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="bg-slate-800/70 backdrop-blur-md shadow-2xl rounded-xl p-6">
        <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
          <h2 className="text-2xl font-bold text-white">Resumo da Base de Leads</h2>
          <div className="flex gap-3">
            <input
              type="file"
              accept=".csv"
              ref={fileInputRef}
              onChange={internalHandleFileUpload}
              className="hidden"
            />
            <Button 
              variant="outline" 
              className="border-sky-500/70 text-sky-400 hover:bg-sky-500/10 hover:text-sky-300 transition-colors"
              onClick={() => fileInputRef.current && fileInputRef.current.click()}
            >
              <UploadCloud className="h-4 w-4 mr-2" /> Importar CSV de Leads
            </Button>
            <Button 
              variant="outline" 
              className="border-green-500/70 text-green-400 hover:bg-green-500/10 hover:text-green-300 transition-colors"
              onClick={handleExportData}
            >
              <Download className="h-4 w-4 mr-2" /> Exportar Dados Filtrados (CSV)
            </Button>
          </div>
        </div>
        <FilterControls 
          filters={filters}
          setFilters={setFilters}
          handleApplyFilters={handleApplyFilters}
        />
      </div>
      <KpiCards kpis={kpis} />
      <Charts 
        bancoData={bancoData}
        estadoData={estadoData}
        idadeData={idadeData}
        rendaData={rendaData}
        chartOptions={chartOptions}
        pieOptions={pieOptions}
        filteredDataPresent={filteredData.length > 0}
      />
    </motion.div>
  );
};

export default ResumoBase;