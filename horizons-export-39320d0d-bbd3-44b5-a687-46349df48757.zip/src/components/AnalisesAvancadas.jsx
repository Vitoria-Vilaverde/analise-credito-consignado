import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Brain, LineChart, Search, Users, Upload, Cpu, Bot, UserCheck, CheckCircle, Puzzle, Zap, FileText, Activity } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';

const SectionCard = ({ title, icon, children, description }) => {
  const IconComponent = icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="glass-effect rounded-xl p-6 shadow-lg"
    >
      <div className="flex items-center gap-4 mb-4">
        <IconComponent className="h-7 w-7 text-cyan-400" />
        <div>
          <h3 className="text-xl font-semibold text-white">{title}</h3>
          {description && <p className="text-sm text-gray-300 mt-1">{description}</p>}
        </div>
      </div>
      <div className="space-y-4">
        {children}
      </div>
    </motion.div>
  );
};

const ModelCard = ({ title, modelType, inputDesc, outputDesc, application, icon }) => {
  const { toast } = useToast();
  const IconComponent = icon;
  return (
    <div className="bg-slate-800/50 p-5 rounded-lg border border-slate-700 hover:border-cyan-500/50 transition-all card-hover">
      <div className="flex items-center gap-3 mb-3">
        <IconComponent className="h-6 w-6 text-cyan-400"/>
        <h4 className="text-lg font-semibold text-white">{title}</h4>
      </div>
      <p className="text-sm text-gray-400 mb-1"><strong className="text-gray-300">Modelo:</strong> {modelType}</p>
      <p className="text-sm text-gray-400 mb-1"><strong className="text-gray-300">Entrada:</strong> {inputDesc}</p>
      <p className="text-sm text-gray-400 mb-1"><strong className="text-gray-300">Saída:</strong> {outputDesc}</p>
      <p className="text-sm text-gray-400 mb-3"><strong className="text-gray-300">Aplicação:</strong> {application}</p>
      <Button
        size="sm"
        className="w-full bg-cyan-600 hover:bg-cyan-700 text-white shadow-md transition-all transform hover:scale-105"
        onClick={() => toast({
          title: "🚧 Modelo em Desenvolvimento",
          description: `A implementação do modelo ${title} está em andamento! 🚀`
        })}
      >
        <Zap className="h-4 w-4 mr-2" />
        Testar Simulação
      </Button>
    </div>
  );
};


const AnalisesAvancadas = () => {
  const { toast } = useToast();
  const salesFileInputRef = useRef(null);
  const [salesDataInfo, setSalesDataInfo] = useState({ count: 0, name: null, headersValid: false });
  const [crossMatchResults, setCrossMatchResults] = useState({
    converted: '(Aguardando cruzamento)',
    contactedNotConverted: '(Aguardando cruzamento)',
    multipleContacts: '(Aguardando cruzamento)',
  });

  const expectedSalesHeaders = [
    "CONSULTOR", "DATA", "CLIENTE", "CPF", "ORGAO", "PRODUTO", 
    "BANCO", "VALOR", "ORIGEM", "EQUIPE", "SEGURO"
  ];

  useEffect(() => {
    const storedSalesData = localStorage.getItem('analises_salesData');
    if (storedSalesData) {
      try {
        const parsedData = JSON.parse(storedSalesData);
        if (parsedData && parsedData.data && Array.isArray(parsedData.data)) {
            setSalesDataInfo({ 
                count: parsedData.data.length || 0, 
                name: parsedData.name || 'Dados de Vendas Salvos',
                headersValid: parsedData.headersValid || false,
            });
        }
      } catch (error) {
        console.error("Erro ao carregar dados de vendas do localStorage:", error);
        localStorage.removeItem('analises_salesData');
      }
    }

    const storedMatchResults = localStorage.getItem('analises_matchResults');
    if(storedMatchResults) {
      try {
        setCrossMatchResults(JSON.parse(storedMatchResults));
      } catch (error) {
        console.error("Erro ao carregar resultados de cruzamento do localStorage:", error);
        localStorage.removeItem('analises_matchResults');
      }
    }
  }, []);

  const showToastNotImplemented = (feature) => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: `A funcionalidade "${feature}" ainda não foi implementada. Você pode solicitá-la no próximo prompt! 🚀`
    });
  };

  const handleImportSalesCSV = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target.result;
        const lines = text.split('\n').filter(line => line.trim() !== '');
        if (lines.length < 2) {
          toast({ title: "Erro no Arquivo", description: "Arquivo CSV vazio ou sem dados.", variant: "destructive" });
          return;
        }
        
        const header = lines[0].split(',').map(h => h.trim().toUpperCase());
        
        const headersAreValid = expectedSalesHeaders.every(expectedHeader => header.includes(expectedHeader.toUpperCase()));

        if (!headersAreValid) {
          toast({
            title: "Erro de Cabeçalho",
            description: `O cabeçalho do arquivo CSV de vendas não corresponde ao esperado. Verifique as colunas: ${expectedSalesHeaders.join(', ')}.`,
            variant: "destructive",
            duration: 7000,
          });
          setSalesDataInfo({ count: 0, name: file.name, headersValid: false });
          localStorage.removeItem('analises_salesData');
          return;
        }
        
        const data = lines.slice(1).map(line => {
          const values = line.split(',').map(v => v.trim());
          return header.reduce((obj, nextKey, index) => {
            obj[nextKey] = values[index];
            return obj;
          }, {});
        });
        
        const salesDataObject = {
            name: file.name,
            data: data,
            headersValid: true,
            importedAt: new Date().toISOString()
        };

        localStorage.setItem('analises_salesData', JSON.stringify(salesDataObject));
        setSalesDataInfo({ count: data.length, name: file.name, headersValid: true });
        toast({
          title: "Sucesso!",
          description: `Arquivo de Vendas "${file.name}" (${data.length} registros) importado e salvo localmente.`,
          variant: "default",
          className: "bg-green-600 text-white border-green-700"
        });
      };
      reader.onerror = () => {
        toast({ title: "Erro de Leitura", description: "Não foi possível ler o arquivo.", variant: "destructive" });
      };
      reader.readAsText(file);
    }
    if (event.target) {
        event.target.value = null; 
    }
  };

  const handleCrossMatch = () => {
    const storedSalesData = localStorage.getItem('analises_salesData');
    let salesDataValid = false;
    if (storedSalesData) {
        try {
            const parsed = JSON.parse(storedSalesData);
            if (parsed && parsed.data && parsed.data.length > 0 && parsed.headersValid) {
                salesDataValid = true;
            }
        } catch (e) { /* ignore */ }
    }

    if (!salesDataValid) {
      toast({
        title: "Atenção!",
        description: "Importe a base de vendas (CSV) com o cabeçalho correto antes de cruzar os dados.",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Processando...",
      description: "Cruzando bases de leads e vendas. Isso pode levar um momento.",
    });

    setTimeout(() => {
      const simulatedResults = {
        converted: Math.floor(Math.random() * 100) + 50,
        contactedNotConverted: Math.floor(Math.random() * 200) + 100,
        multipleContacts: Math.floor(Math.random() * 50) + 20,
      };
      setCrossMatchResults(simulatedResults);
      localStorage.setItem('analises_matchResults', JSON.stringify(simulatedResults));
      toast({
        title: "Cruzamento Concluído!",
        description: "Resultados do cruzamento de bases simulados e atualizados.",
        variant: "default",
        className: "bg-blue-600 text-white border-blue-700"
      });
    }, 2000);
  };

  const conversionFactors = [
    { id: "produto", label: "Produto" },
    { id: "convenio", label: "Convênio / Órgão" },
    { id: "perfilMargem", label: "Perfil de Margem" },
    { id: "faixaEtaria", label: "Faixa Etária" },
    { id: "canal", label: "Canal (Origem)" },
    { id: "scoreInterno", label: "Score Interno" },
  ];

  return (
    <div className="space-y-8">
      <input
        type="file"
        accept=".csv"
        ref={salesFileInputRef}
        onChange={handleImportSalesCSV}
        className="hidden"
      />
      <SectionCard 
        title="Análise de Conversão por Características do Lead" 
        icon={LineChart}
        description="Entenda o perfil ideal de cliente que fecha negócio analisando taxas de conversão por diferentes atributos."
      >
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {conversionFactors.map(factor => (
            <div key={factor.id} className="flex items-center space-x-2 bg-slate-800/50 p-3 rounded-md">
              <Checkbox id={`conv-${factor.id}`} className="border-cyan-400 data-[state=checked]:bg-cyan-500 data-[state=checked]:border-cyan-500"/>
              <Label htmlFor={`conv-${factor.id}`} className="text-sm text-gray-200 cursor-pointer">{factor.label}</Label>
            </div>
          ))}
        </div>
        <Button 
            className="w-full md:w-auto bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white shadow-lg transition-all transform hover:scale-105"
            onClick={() => showToastNotImplemented('Gerar Análise de Conversão')}
        >
          <Activity className="h-4 w-4 mr-2" />
          Gerar Análise de Conversão
        </Button>
      </SectionCard>

      <SectionCard 
        title="Match entre Lead e Venda" 
        icon={Search}
        description="Cruze sua base de leads com a base de vendas para identificar padrões e otimizar o funil."
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Button 
            variant="outline" 
            className={`w-full border-green-500/70 text-green-400 hover:bg-green-500/10 hover:text-green-300 transition-colors ${salesDataInfo.headersValid ? 'border-green-500' : 'border-yellow-500 text-yellow-400 hover:text-yellow-300'}`}
            onClick={() => salesFileInputRef.current.click()}
          >
            <Upload className="h-4 w-4 mr-2" />
            {salesDataInfo.name ? 
              `Vendas: ${salesDataInfo.name.substring(0,15)}... (${salesDataInfo.count}) ${salesDataInfo.headersValid ? '✓' : '⚠️'}` 
              : 'Importar Base de Vendas (CSV)'}
          </Button>
          <Button 
            className="w-full bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 text-white shadow-lg transition-all transform hover:scale-105"
            onClick={handleCrossMatch}
            disabled={!salesDataInfo.headersValid || salesDataInfo.count === 0}
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Cruzar Bases e Identificar Matches
          </Button>
        </div>
        <div className="mt-4 p-4 bg-slate-800/50 rounded-md border border-slate-700">
            <div className="flex items-center gap-2 mb-2">
              <FileText className="h-5 w-5 text-gray-400"/>
              <h4 className="text-md font-semibold text-gray-200">Resultados do Cruzamento (Simulado):</h4>
            </div>
            <ul className="list-disc list-inside text-sm text-gray-300 space-y-1 pl-2">
                <li>Leads que viraram venda: <strong className="text-green-400">{crossMatchResults.converted}</strong></li>
                <li>Leads contatados, não convertidos: <strong className="text-yellow-400">{crossMatchResults.contactedNotConverted}</strong></li>
                <li>Leads com múltiplos contatos: <strong className="text-blue-400">{crossMatchResults.multipleContacts}</strong></li>
            </ul>
            {salesDataInfo.count > 0 && (
                <p className={`text-xs mt-2 ${salesDataInfo.headersValid ? 'text-gray-400' : 'text-yellow-500'}`}>
                    Base de vendas importada: {salesDataInfo.count} registros. {salesDataInfo.headersValid ? '(Cabeçalho OK)' : '(Cabeçalho Inválido!)'}
                </p>
            )}
        </div>
      </SectionCard>

      <SectionCard 
        title="🤖 Modelos de Machine Learning Sugeridos" 
        icon={Cpu}
        description="Explore modelos de ML para otimizar suas estratégias de conversão e segmentação."
      >
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ModelCard 
            title="Classificação de Conversão (Lead Scoring)"
            modelType="Random Forest / XGBoost"
            inputDesc="Características do lead (idade, convênio, margem, score, produto, canal)"
            outputDesc="Probabilidade de conversão"
            application="Ordenar sua base por chance real de fechar negócio."
            icon={Bot}
          />
          <ModelCard 
            title="Recomendação de Produto Ideal"
            modelType="Classificador multiclasse (Árvore de Decisão / Rede Neural Simples)"
            inputDesc="Perfil do lead"
            outputDesc="Produto mais provável de ser contratado"
            application="Sugerir o produto certo para o cliente certo."
            icon={Puzzle}
          />
          <ModelCard 
            title="Clusterização de Leads (K-Means)"
            modelType="K-Means"
            inputDesc="Características do lead"
            outputDesc="Grupos de leads com perfis similares"
            application="Segmentar a base em perfis (ex: “tomador recorrente”, “alto risco”)."
            icon={Users}
          />
          <ModelCard 
            title="Análise de Aderência do Operador"
            modelType="Análise de Dados Cruzados / Modelo de Afinidade"
            inputDesc="Dados de operadores e tipos de venda/perfil de cliente"
            outputDesc="Quem vende melhor para qual perfil de cliente"
            application="Roteamento inteligente de leads para operadores com maior afinidade."
            icon={UserCheck}
          />
        </div>
      </SectionCard>
    </div>
  );
};

export default AnalisesAvancadas;