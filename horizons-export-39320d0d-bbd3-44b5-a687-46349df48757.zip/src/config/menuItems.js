import {
  BarChart2,
  List,
  Users,
  GitMerge,
  PhoneCall,
  Settings,
  Shield,
  Zap,
  BookOpen,
  ClipboardList
} from 'lucide-react';

export const menuItems = [
  { id: 'resumo', label: 'Resumo da Base', icon: BarChart2, component: 'ResumoBase' },
  { id: 'base', label: 'Base Carregada', icon: ClipboardList, component: 'BaseCarregada' },
  { id: 'segmentacao', label: 'Segmentação', icon: List, component: 'Segmentacao' },
  { id: 'gestao', label: 'Gestão de Clientes', icon: Users, component: 'GestaoClientes' },
  { id: 'margens', label: 'Atualização de Margens', icon: GitMerge, component: 'AtualizacaoMargens' },
  { id: 'telefones', label: 'Nova Vida para Telefones', icon: PhoneCall, component: 'NovaVidaTelefones' },
  { id: 'regras', label: 'Regras de Segmentação', icon: Settings, component: 'RegrasSegmentacao' },
  { id: 'analises', label: 'Análises Avançadas', icon: Zap, component: 'AnalisesAvancadas' },
  { id: 'usuarios', label: 'Administração', icon: Shield, component: 'AdministracaoUsuarios' },
  { id: 'integracoes', label: 'Integrações', icon: Zap, component: 'Integracoes' },
  { id: 'logs', label: 'Logs de Atividade', icon: BookOpen, component: 'ActivityLog' },
];